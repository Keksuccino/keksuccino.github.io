package de.keksuccino.rinku;

/** Build-generated identity binding the Java API and downloaded native runtime to one JCEF release. */
public final class JcefRuntimeIdentity {

    public static final String JAVA_CEF_COMMIT = "2eb4ca2648bda91d1dfed81e9a37ba92e757aff9";

    private JcefRuntimeIdentity() {}

}
