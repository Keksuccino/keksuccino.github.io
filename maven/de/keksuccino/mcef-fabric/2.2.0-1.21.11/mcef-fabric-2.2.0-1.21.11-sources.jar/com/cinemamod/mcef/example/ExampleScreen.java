package com.cinemamod.mcef.example;

import com.cinemamod.mcef.MCEF;
import com.cinemamod.mcef.MCEFBrowser;
import net.minecraft.class_10799;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.cef.browser.CefBrowser;
import org.cef.browser.CefFrame;
import org.cef.handler.CefDisplayHandler;
import org.cef.handler.CefDisplayHandlerAdapter;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.glfw.GLFW;

public class ExampleScreen extends class_437 {

    private static final int FRAME_MARGIN = 20;
    private static final int NAV_BAR_HEIGHT = 20;
    private static final int NAV_BAR_GAP = 6;
    private static final int NAV_BUTTON_WIDTH = 24;
    private static final int NAV_SPACING = 4;
    private static final int LOADING_BAR_HEIGHT = 2;
    private static final int LOADING_BAR_TRACK_COLOR = 0x55000000;
    private static final int LOADING_BAR_FILL_COLOR = 0xFF3BA8FF;
    private static final String DEFAULT_URL = "https://www.google.com";

    private MCEFBrowser browser;
    private class_342 urlBox;
    private class_4185 backButton;
    private class_4185 forwardButton;
    private class_4185 reloadButton;
    private CefDisplayHandler addressBarDisplayHandler;

    public ExampleScreen(class_2561 component) {
        super(component);
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        if (browser == null) {
            boolean transparent = true;
            browser = MCEF.createBrowser(DEFAULT_URL, transparent);
        }
        registerAddressBarDisplayHandler();
        initNavigationWidgets();
        resizeBrowser();
        refreshNavigationState();
    }

    private void registerAddressBarDisplayHandler() {
        if (addressBarDisplayHandler != null) {
            return;
        }

        addressBarDisplayHandler = new CefDisplayHandlerAdapter() {
            @Override
            public void onAddressChange(CefBrowser cefBrowser, CefFrame frame, String url) {
                if (browser == null || cefBrowser == null || frame == null || !frame.isMain()) {
                    return;
                }
                if (cefBrowser.getIdentifier() != browser.getIdentifier()) {
                    return;
                }

                field_22787.execute(() -> {
                    if (field_22787.field_1755 != ExampleScreen.this || urlBox == null || url == null || url.isBlank()) {
                        return;
                    }
                    if (!url.equals(urlBox.method_1882())) {
                        urlBox.method_1852(url);
                    }
                });
            }
        };
        MCEF.getClient().addDisplayHandler(addressBarDisplayHandler);
    }

    private void initNavigationWidgets() {
        int navX = FRAME_MARGIN;
        int navY = FRAME_MARGIN;

        backButton = method_37063(
                class_4185.method_46430(class_2561.method_43470("<"), (button) -> browser.goBack())
                        .method_46434(navX, navY, NAV_BUTTON_WIDTH, NAV_BAR_HEIGHT)
                        .method_46431()
        );
        navX += NAV_BUTTON_WIDTH + NAV_SPACING;

        forwardButton = method_37063(
                class_4185.method_46430(class_2561.method_43470(">"), (button) -> browser.goForward())
                        .method_46434(navX, navY, NAV_BUTTON_WIDTH, NAV_BAR_HEIGHT)
                        .method_46431()
        );
        navX += NAV_BUTTON_WIDTH + NAV_SPACING;

        reloadButton = method_37063(
                class_4185.method_46430(class_2561.method_43470("R"), (button) -> browser.reload())
                        .method_46434(navX, navY, NAV_BUTTON_WIDTH, NAV_BAR_HEIGHT)
                        .method_46431()
        );
        navX += NAV_BUTTON_WIDTH + NAV_SPACING;

        int urlWidth = Math.max(60, field_22789 - FRAME_MARGIN - navX);
        urlBox = method_37063(new class_342(field_22793, navX, navY, urlWidth, NAV_BAR_HEIGHT, class_2561.method_43470("URL")));
        urlBox.method_1880(2048);
        String currentUrl = browser.getURL();
        urlBox.method_1852(currentUrl == null || currentUrl.isBlank() ? DEFAULT_URL : currentUrl);
    }

    private int getBrowserX() {
        return FRAME_MARGIN;
    }

    private int getBrowserY() {
        return FRAME_MARGIN + NAV_BAR_HEIGHT + NAV_BAR_GAP;
    }

    private int getBrowserWidth() {
        return Math.max(1, field_22789 - FRAME_MARGIN * 2);
    }

    private int getBrowserHeight() {
        return Math.max(1, field_22790 - getBrowserY() - FRAME_MARGIN);
    }

    private boolean isInBrowserBounds(double x, double y) {
        int browserX = getBrowserX();
        int browserY = getBrowserY();
        return x >= browserX && y >= browserY && x < (browserX + getBrowserWidth()) && y < (browserY + getBrowserHeight());
    }

    private int mouseX(double x) {
        return (int) ((x - getBrowserX()) * field_22787.method_22683().method_4495());
    }

    private int mouseY(double y) {
        return (int) ((y - getBrowserY()) * field_22787.method_22683().method_4495());
    }

    private void resizeBrowser() {
        if (browser != null) {
            browser.resize((int) (getBrowserWidth() * field_22787.method_22683().method_4495()), (int) (getBrowserHeight() * field_22787.method_22683().method_4495()));
        }
    }

    @Override
    public void method_25410(int i, int j) {
        super.method_25410(i, j);
        resizeBrowser();
    }

    @Override
    public void method_25419() {
        if (addressBarDisplayHandler != null && MCEF.isInitialized()) {
            MCEF.getClient().removeDisplayHandler(addressBarDisplayHandler);
        }
        addressBarDisplayHandler = null;
        browser.close();
        super.method_25419();
    }

    @Override
    public void method_25393() {
        super.method_25393();
        refreshNavigationState();
    }

    private void refreshNavigationState() {
        if (browser == null) {
            return;
        }

        if (backButton != null) {
            backButton.field_22763 = browser.canGoBack();
        }
        if (forwardButton != null) {
            forwardButton.field_22763 = browser.canGoForward();
        }
        if (reloadButton != null) {
            reloadButton.field_22763 = true;
        }

        if (urlBox != null && !urlBox.method_25370()) {
            String currentUrl = browser.getURL();
            if (currentUrl != null && !currentUrl.isBlank() && !currentUrl.equals(urlBox.method_1882())) {
                urlBox.method_1852(currentUrl);
            }
        }
    }

    private void navigateFromUrlField() {
        if (urlBox == null) {
            return;
        }

        String input = urlBox.method_1882();
        if (input == null) {
            return;
        }
        input = input.trim();
        if (input.isEmpty()) {
            return;
        }

        String normalizedUrl = normalizeUrl(input);
        urlBox.method_1852(normalizedUrl);
        browser.loadURL(normalizedUrl);
        browser.setFocus(true);
    }

    private String normalizeUrl(String input) {
        if (input.matches("^[a-zA-Z][a-zA-Z0-9+.-]*:.*")) {
            return input;
        }
        return "https://" + input;
    }

    @Override
    public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partial) {

        super.method_25394(guiGraphics, mouseX, mouseY, partial);
        renderLoadingIndicator(guiGraphics);
        
        // Check if the browser texture is ready for rendering
        if (browser != null && browser.isTextureReady()) {
            renderBrowserTexture(guiGraphics);
        }

    }
    
    private void renderBrowserTexture(class_332 guiGraphics) {

        // Get the Identifier for the browser texture
        class_2960 textureLocation = browser.getTextureIdentifier();
        if (textureLocation == null) {
            return;
        }

        int frameRenderWidth = getBrowserWidth();
        int frameRenderHeight = getBrowserHeight();
        guiGraphics.method_25290(
                class_10799.field_56883,
                textureLocation,
                getBrowserX(),
                getBrowserY(),
                0.0F,
                0.0F,
                frameRenderWidth,
                frameRenderHeight,
                frameRenderWidth,
                frameRenderHeight
        );

    }

    private void renderLoadingIndicator(class_332 guiGraphics) {
        if (browser == null || urlBox == null || !browser.isLoading()) {
            return;
        }

        int barX = urlBox.method_46426();
        int barY = urlBox.method_46427() + 1;
        int barWidth = urlBox.method_25368();
        int barBottom = barY + LOADING_BAR_HEIGHT;
        guiGraphics.method_25294(barX, barY, barX + barWidth, barBottom, LOADING_BAR_TRACK_COLOR);

        int segmentWidth = Math.max(20, barWidth / 4);
        int travelRange = barWidth + segmentWidth;
        int animatedOffset = (int) ((class_156.method_658() / 6L) % travelRange) - segmentWidth;
        int segmentStart = Math.max(barX, barX + animatedOffset);
        int segmentEnd = Math.min(barX + barWidth, barX + animatedOffset + segmentWidth);
        if (segmentEnd > segmentStart) {
            guiGraphics.method_25294(segmentStart, barY, segmentEnd, barBottom, LOADING_BAR_FILL_COLOR);
        }
    }

    @Override
    public boolean method_25402(class_11909 event, boolean isDoubleClick) {
        boolean handled = super.method_25402(event, isDoubleClick);
        if (handled) {
            return true;
        }

        if (!isInBrowserBounds(event.comp_4798(), event.comp_4799())) {
            return false;
        }

        browser.sendMousePress(mouseX(event.comp_4798()), mouseY(event.comp_4799()), event.method_74245());
        browser.setFocus(true);
        return true;
    }

    @Override
    public boolean method_25406(class_11909 event) {
        boolean handled = super.method_25406(event);
        if (handled) {
            return true;
        }

        browser.sendMouseRelease(mouseX(event.comp_4798()), mouseY(event.comp_4799()), event.method_74245());
        browser.setFocus(true);
        return true;
    }

    @Override
    public void method_16014(double mouseX, double mouseY) {
        if (isInBrowserBounds(mouseX, mouseY)) {
            browser.sendMouseMove(this.mouseX(mouseX), this.mouseY(mouseY));
        }
        super.method_16014(mouseX, mouseY);
    }

    @Override
    public boolean method_25403(class_11909 event, double dragX, double dragY) {
        return super.method_25403(event, dragX, dragY);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        boolean handled = super.method_25401(mouseX, mouseY, scrollX, scrollY);
        if (handled) {
            return true;
        }

        if (!isInBrowserBounds(mouseX, mouseY)) {
            return false;
        }

        browser.sendMouseWheel(this.mouseX(mouseX), this.mouseY(mouseY), scrollY, 0);
        return true;
    }

    @Override
    public boolean method_25404(class_11908 event) {
        if (urlBox != null && urlBox.method_25370() && (event.comp_4795() == GLFW.GLFW_KEY_ENTER || event.comp_4795() == GLFW.GLFW_KEY_KP_ENTER)) {
            navigateFromUrlField();
            method_25395(null);
            browser.setFocus(true);
            return true;
        }

        if (super.method_25404(event)) {
            return true;
        }

        if (urlBox != null && urlBox.method_25370()) {
            return true;
        }

        browser.sendKeyPress(event.comp_4795(), event.comp_4796(), event.comp_4797());
        browser.setFocus(true);
        return true;
    }

    @Override
    public boolean method_16803(class_11908 event) {
        if (super.method_16803(event)) {
            return true;
        }

        if (urlBox != null && urlBox.method_25370()) {
            return true;
        }

        browser.sendKeyRelease(event.comp_4795(), event.comp_4796(), event.comp_4797());
        browser.setFocus(true);
        return true;
    }

    @Override
    public boolean method_25400(class_11905 event) {
        if (super.method_25400(event)) {
            return true;
        }

        if (urlBox != null && urlBox.method_25370()) {
            return true;
        }

        if (event.comp_4793() == (char) 0) return false;
        browser.sendKeyTyped((char) event.comp_4793(), event.comp_4794());
        browser.setFocus(true);
        return true;
    }

}
