package com.cinemamod.mcef.example;

import com.cinemamod.mcef.MCEF;
import com.cinemamod.mcef.MCEFBrowser;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import org.cef.browser.CefBrowser;
import org.cef.browser.CefFrame;
import org.cef.handler.CefDisplayHandler;
import org.cef.handler.CefDisplayHandlerAdapter;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.glfw.GLFW;

public class ExampleScreen extends class_437 {

    private static final int FRAME_MARGIN = 20;
    private static final int NAV_BAR_HEIGHT = 20;
    private static final int NAV_BAR_GAP = 6;
    private static final int NAV_BUTTON_WIDTH = 24;
    private static final int NAV_SPACING = 4;
    private static final int LOADING_BAR_HEIGHT = 2;
    private static final int LOADING_BAR_TRACK_COLOR = 0x55000000;
    private static final int LOADING_BAR_FILL_COLOR = 0xFF3BA8FF;
    private static final String DEFAULT_URL = "https://www.google.com";

    private MCEFBrowser browser;
    private class_342 urlBox;
    private class_4185 backButton;
    private class_4185 forwardButton;
    private class_4185 reloadButton;
    private CefDisplayHandler addressBarDisplayHandler;

    public ExampleScreen(class_2561 component) {
        super(component);
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        if (browser == null) {
            boolean transparent = true;
            browser = MCEF.createBrowser(DEFAULT_URL, transparent);
        }
        registerAddressBarDisplayHandler();
        initNavigationWidgets();
        resizeBrowser();
        refreshNavigationState();
    }

    private void registerAddressBarDisplayHandler() {
        if (addressBarDisplayHandler != null) {
            return;
        }

        addressBarDisplayHandler = new CefDisplayHandlerAdapter() {
            @Override
            public void onAddressChange(CefBrowser cefBrowser, CefFrame frame, String url) {
                if (browser == null || cefBrowser == null || frame == null || !frame.isMain()) {
                    return;
                }
                if (cefBrowser.getIdentifier() != browser.getIdentifier()) {
                    return;
                }

                field_22787.execute(() -> {
                    if (field_22787.field_1755 != ExampleScreen.this || urlBox == null || url == null || url.isBlank()) {
                        return;
                    }
                    if (!url.equals(urlBox.method_1882())) {
                        urlBox.method_1852(url);
                    }
                });
            }
        };
        MCEF.getClient().addDisplayHandler(addressBarDisplayHandler);
    }

    private void initNavigationWidgets() {
        int navX = FRAME_MARGIN;
        int navY = FRAME_MARGIN;

        backButton = method_37063(
                new class_4185(navX, navY, NAV_BUTTON_WIDTH, NAV_BAR_HEIGHT, class_2561.method_43470("<"), (button) -> browser.goBack())
        );
        navX += NAV_BUTTON_WIDTH + NAV_SPACING;

        forwardButton = method_37063(
                new class_4185(navX, navY, NAV_BUTTON_WIDTH, NAV_BAR_HEIGHT, class_2561.method_43470(">"), (button) -> browser.goForward())
        );
        navX += NAV_BUTTON_WIDTH + NAV_SPACING;

        reloadButton = method_37063(
                new class_4185(navX, navY, NAV_BUTTON_WIDTH, NAV_BAR_HEIGHT, class_2561.method_43470("R"), (button) -> browser.reload())
        );
        navX += NAV_BUTTON_WIDTH + NAV_SPACING;

        int urlWidth = Math.max(60, field_22789 - FRAME_MARGIN - navX);
        urlBox = method_37063(new class_342(field_22793, navX, navY, urlWidth, NAV_BAR_HEIGHT, class_2561.method_43470("URL")));
        urlBox.method_1880(2048);
        String currentUrl = browser.getURL();
        urlBox.method_1852(currentUrl == null || currentUrl.isBlank() ? DEFAULT_URL : currentUrl);
    }

    private int getBrowserX() {
        return FRAME_MARGIN;
    }

    private int getBrowserY() {
        return FRAME_MARGIN + NAV_BAR_HEIGHT + NAV_BAR_GAP;
    }

    private int getBrowserWidth() {
        return Math.max(1, field_22789 - FRAME_MARGIN * 2);
    }

    private int getBrowserHeight() {
        return Math.max(1, field_22790 - getBrowserY() - FRAME_MARGIN);
    }

    private boolean isInBrowserBounds(double x, double y) {
        int browserX = getBrowserX();
        int browserY = getBrowserY();
        return x >= browserX && y >= browserY && x < (browserX + getBrowserWidth()) && y < (browserY + getBrowserHeight());
    }

    private int mouseX(double x) {
        return (int) ((x - getBrowserX()) * field_22787.method_22683().method_4495());
    }

    private int mouseY(double y) {
        return (int) ((y - getBrowserY()) * field_22787.method_22683().method_4495());
    }

    private void resizeBrowser() {
        if (browser != null) {
            browser.resize((int) (getBrowserWidth() * field_22787.method_22683().method_4495()), (int) (getBrowserHeight() * field_22787.method_22683().method_4495()));
        }
    }

    @Override
    public void method_25410(@NotNull class_310 minecraft, int width, int height) {
        super.method_25410(minecraft, width, height);
        resizeBrowser();
    }

    @Override
    public void method_25419() {
        if (addressBarDisplayHandler != null && MCEF.isInitialized()) {
            MCEF.getClient().removeDisplayHandler(addressBarDisplayHandler);
        }
        addressBarDisplayHandler = null;
        if (browser != null) {
            browser.close();
        }
        super.method_25419();
    }

    @Override
    public void method_25393() {
        super.method_25393();
        if (urlBox != null) {
            urlBox.method_1865();
        }
        refreshNavigationState();
    }

    private void refreshNavigationState() {
        if (browser == null) {
            return;
        }

        if (backButton != null) {
            backButton.field_22763 = browser.canGoBack();
        }
        if (forwardButton != null) {
            forwardButton.field_22763 = browser.canGoForward();
        }
        if (reloadButton != null) {
            reloadButton.field_22763 = true;
        }

        if (urlBox != null && !urlBox.method_25370()) {
            String currentUrl = browser.getURL();
            if (currentUrl != null && !currentUrl.isBlank() && !currentUrl.equals(urlBox.method_1882())) {
                urlBox.method_1852(currentUrl);
            }
        }
    }

    private void navigateFromUrlField() {
        if (urlBox == null || browser == null) {
            return;
        }

        String input = urlBox.method_1882();
        if (input == null) {
            return;
        }
        input = input.trim();
        if (input.isEmpty()) {
            return;
        }

        String normalizedUrl = normalizeUrl(input);
        urlBox.method_1852(normalizedUrl);
        browser.loadURL(normalizedUrl);
        clearNavigationFocus_MCEF();
        browser.setFocus(true);
    }

    private void clearNavigationFocus_MCEF() {
        method_20086(null);
        if (backButton != null && backButton.method_25370()) {
            backButton.method_25407(false);
        }
        if (forwardButton != null && forwardButton.method_25370()) {
            forwardButton.method_25407(false);
        }
        if (reloadButton != null && reloadButton.method_25370()) {
            reloadButton.method_25407(false);
        }
        if (urlBox != null) {
            urlBox.method_1876(false);
        }
    }

    private String normalizeUrl(String input) {
        if (input.matches("^[a-zA-Z][a-zA-Z0-9+.-]*:.*")) {
            return input;
        }
        return "https://" + input;
    }

    @Override
    public void method_25394(@NotNull class_4587 poseStack, int mouseX, int mouseY, float partial) {
        super.method_25394(poseStack, mouseX, mouseY, partial);
        renderLoadingIndicator(poseStack);
        
        // Check if the browser texture is ready for rendering
        if (browser != null && browser.isTextureReady()) {
            renderBrowserTexture(poseStack);
        }

    }
    
    private void renderBrowserTexture(class_4587 poseStack) {

        // Get the Identifier for the browser texture
        class_2960 textureLocation = browser.getTextureLocation();
        if (textureLocation == null) {
            return;
        }

        int frameRenderWidth = getBrowserWidth();
        int frameRenderHeight = getBrowserHeight();
        int textureWidth = browser.getRenderer().getTextureWidth();
        int textureHeight = browser.getRenderer().getTextureHeight();
        if (textureWidth <= 0 || textureHeight <= 0) {
            return;
        }

        RenderSystem.setShaderTexture(0, textureLocation);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        method_25293(
                poseStack,
                getBrowserX(),
                getBrowserY(),
                frameRenderWidth,
                frameRenderHeight,
                0.0F,
                0.0F,
                textureWidth,
                textureHeight,
                textureWidth,
                textureHeight
        );

    }

    private void renderLoadingIndicator(class_4587 poseStack) {
        if (browser == null || urlBox == null || !browser.isLoading()) {
            return;
        }

        int barX = urlBox.field_22760;
        int barY = urlBox.field_22761 + 1;
        int barWidth = urlBox.method_25368();
        int barBottom = barY + LOADING_BAR_HEIGHT;
        method_25294(poseStack, barX, barY, barX + barWidth, barBottom, LOADING_BAR_TRACK_COLOR);

        int segmentWidth = Math.max(20, barWidth / 4);
        int travelRange = barWidth + segmentWidth;
        int animatedOffset = (int) ((class_156.method_658() / 6L) % travelRange) - segmentWidth;
        int segmentStart = Math.max(barX, barX + animatedOffset);
        int segmentEnd = Math.min(barX + barWidth, barX + animatedOffset + segmentWidth);
        if (segmentEnd > segmentStart) {
            method_25294(poseStack, segmentStart, barY, segmentEnd, barBottom, LOADING_BAR_FILL_COLOR);
        }
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        boolean handled = super.method_25402(mouseX, mouseY, button);
        if (handled) {
            return true;
        }

        if (!isInBrowserBounds(mouseX, mouseY)) {
            return false;
        }

        clearNavigationFocus_MCEF();
        browser.sendMousePress(mouseX(mouseX), mouseY(mouseY), button);
        browser.setFocus(true);
        return true;
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        boolean handled = super.method_25406(mouseX, mouseY, button);
        if (handled) {
            return true;
        }

        browser.sendMouseRelease(this.mouseX(mouseX), this.mouseY(mouseY), button);
        browser.setFocus(true);
        return true;
    }

    @Override
    public void method_16014(double mouseX, double mouseY) {
        if (isInBrowserBounds(mouseX, mouseY)) {
            browser.sendMouseMove(this.mouseX(mouseX), this.mouseY(mouseY));
        }
        super.method_16014(mouseX, mouseY);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
        return super.method_25403(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollY) {
        boolean handled = super.method_25401(mouseX, mouseY, scrollY);
        if (handled) {
            return true;
        }

        if (!isInBrowserBounds(mouseX, mouseY)) {
            return false;
        }

        browser.sendMouseWheel(this.mouseX(mouseX), this.mouseY(mouseY), scrollY, 0);
        return true;
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (urlBox != null && urlBox.method_25370() && (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER)) {
            navigateFromUrlField();
            return true;
        }

        if (super.method_25404(keyCode, scanCode, modifiers)) {
            return true;
        }

        if (urlBox != null && urlBox.method_25370()) {
            return true;
        }

        browser.sendKeyPress(keyCode, scanCode, modifiers);
        browser.setFocus(true);
        return true;
    }

    @Override
    public boolean method_16803(int keyCode, int scanCode, int modifiers) {
        if (super.method_16803(keyCode, scanCode, modifiers)) {
            return true;
        }

        if (urlBox != null && urlBox.method_25370()) {
            return true;
        }

        browser.sendKeyRelease(keyCode, scanCode, modifiers);
        browser.setFocus(true);
        return true;
    }

    @Override
    public boolean method_25400(char codePoint, int modifiers) {
        if (super.method_25400(codePoint, modifiers)) {
            return true;
        }

        if (urlBox != null && urlBox.method_25370()) {
            return true;
        }

        if (codePoint == 0) return false;
        browser.sendKeyTyped(codePoint, modifiers);
        browser.setFocus(true);
        return true;
    }

}
