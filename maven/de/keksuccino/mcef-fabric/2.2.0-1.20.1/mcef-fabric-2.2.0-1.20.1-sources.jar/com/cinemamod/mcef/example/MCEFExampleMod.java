package com.cinemamod.mcef.example;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;

public class MCEFExampleMod {

    public static final class_304 KEY_MAPPING = new class_304("Open Browser", class_3675.field_31927, class_304.field_32137);

    public MCEFExampleMod() {
        ClientTickEvents.START_CLIENT_TICK.register((client) -> onTick());
        KeyBindingHelper.registerKeyBinding(KEY_MAPPING);
    }

    public void onTick() {
        // Check if our key was pressed
        if (KEY_MAPPING.method_1434() && !(class_310.method_1551().field_1755 instanceof ExampleScreen)) {
            //Display the web browser UI.
            class_310.method_1551().method_1507(new ExampleScreen(class_2561.method_43470("Example Screen")));
        }
    }

}
