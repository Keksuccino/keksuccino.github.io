/*
 *     MCEF (Minecraft Chromium Embedded Framework)
 *     Copyright (C) 2023 CinemaMod Group
 *
 *     This library is free software; you can redistribute it and/or
 *     modify it under the terms of the GNU Lesser General Public
 *     License as published by the Free Software Foundation; either
 *     version 2.1 of the License, or (at your option) any later version.
 *
 *     This library is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *     Lesser General Public License for more details.
 *
 *     You should have received a copy of the GNU Lesser General Public
 *     License along with this library; if not, write to the Free Software
 *     Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301
 *     USA
 */

package com.cinemamod.mcef.internal;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import org.jetbrains.annotations.NotNull;

public class MCEFDownloaderMenu extends class_437 {
    private final class_437 menu;

    public MCEFDownloaderMenu(class_437 menu) {
        super(class_2561.method_43470("MCEF is downloading required libraries...").method_27692(class_124.field_1065));
        this.menu = menu;
    }

    @Override
    public void method_25394(@NotNull class_332 graphics, int mouseX, int mouseY, float partialTick) {
        double cx = field_22789 / 2d;
        double cy = field_22790 / 2d;

        double progressBarHeight = 14;
        double progressBarWidth = field_22789 / 3d;

        this.method_25420(graphics);

        class_4587 matrix = graphics.method_51448();

        /* Draw Progress Bar */
        matrix.method_22903();
        matrix.method_46416((float) cx, (float) cy, 0.0F);
        matrix.method_46416((float) (-progressBarWidth / 2d), (float) (-progressBarHeight / 2d), 0.0F);
        graphics.method_25294( // bar border
                0, 0,
                (int) progressBarWidth,
                (int) progressBarHeight,
                -1
        );
        graphics.method_25294( // bar padding
                2, 2,
                (int) progressBarWidth - 2,
                (int) progressBarHeight - 2,
                -16777215
        );
        graphics.method_25294( // bar bar
                4, 4,
                (int) ((progressBarWidth - 4) * MCEFDownloadListener.INSTANCE.getProgress()),
                (int) progressBarHeight - 4,
                -1
        );
        matrix.method_22909();

        // putting this here incase I want to re-add a third line later on
        // allows me to generalize the code to not care about line count
        String[] text = new String[] {
                MCEFDownloadListener.INSTANCE.getTask(),
                Math.round(MCEFDownloadListener.INSTANCE.getProgress() * 100) + "%",
        };

        /* Draw Text */

        // calculate offset for the top line
        int oSet = ((field_22793.field_2000 / 2) + ((field_22793.field_2000 + 2) * (text.length + 2))) + 4;
        matrix.method_22903();
        matrix.method_46416((float) cx, (float) (cy - oSet), 0.0F);
        // draw menu name
        graphics.method_27535(this.field_22793, this.field_22785, (int) -(field_22793.method_27525(this.field_22785) / 2d), 0, -1);
        // draw other text
        int index = 0;
        for (String s : text) {
            if (index == 1) {
                matrix.method_46416(0.0F, field_22793.field_2000 + 2.0F, 0.0F);
            }
            matrix.method_46416(0.0F, field_22793.field_2000 + 2.0F, 0.0F);
            graphics.method_25303(this.field_22793, s, (int) -(field_22793.method_1727(s) / 2d), 0, -1);
            index++;
        }
        matrix.method_22909();

    }

    @Override
    public void method_25393() {
        if (MCEFDownloadListener.INSTANCE.isDone() || MCEFDownloadListener.INSTANCE.isFailed()) {
            method_25419();
            class_310.method_1551().method_1507(menu);
        }
    }

    @Override
    public boolean method_25422() {
        return false;
    }

    @Override
    public boolean method_25421() {
        return true;
    }

}
