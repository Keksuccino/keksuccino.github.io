/*
 *     MCEF (Minecraft Chromium Embedded Framework)
 *     Copyright (C) 2023 CinemaMod Group
 *
 *     This library is free software; you can redistribute it and/or
 *     modify it under the terms of the GNU Lesser General Public
 *     License as published by the Free Software Foundation; either
 *     version 2.1 of the License, or (at your option) any later version.
 *
 *     This library is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *     Lesser General Public License for more details.
 *
 *     You should have received a copy of the GNU Lesser General Public
 *     License along with this library; if not, write to the Free Software
 *     Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301
 *     USA
 */

package com.cinemamod.mcef.example;

import com.cinemamod.mcef.MCEF;
import com.cinemamod.mcef.MCEFBrowser;
import net.minecraft.class_10799;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.jetbrains.annotations.NotNull;

public class ExampleScreen extends class_437 {

    private static final int BROWSER_DRAW_OFFSET = 20;

    private MCEFBrowser browser;

    public ExampleScreen(class_2561 component) {
        super(component);
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        if (browser == null) {
            String url = "https://www.google.com";
            boolean transparent = true;
            browser = MCEF.createBrowser(url, transparent);
            resizeBrowser();
        }
    }

    private int mouseX(double x) {
        return (int) ((x - BROWSER_DRAW_OFFSET) * field_22787.method_22683().method_4495());
    }

    private int mouseY(double y) {
        return (int) ((y - BROWSER_DRAW_OFFSET) * field_22787.method_22683().method_4495());
    }

    private int scaleX(double x) {
        return (int) ((x - BROWSER_DRAW_OFFSET * 2) * field_22787.method_22683().method_4495());
    }

    private int scaleY(double y) {
        return (int) ((y - BROWSER_DRAW_OFFSET * 2) * field_22787.method_22683().method_4495());
    }

    private void resizeBrowser() {
        if (field_22789 > 100 && field_22790 > 100) {
            browser.resize(scaleX(field_22789), scaleY(field_22790));
        }
    }

    @Override
    public void method_25410(int i, int j) {
        super.method_25410(i, j);
        resizeBrowser();
    }

    @Override
    public void method_25419() {
        browser.close();
        super.method_25419();
    }

    @Override
    public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partial) {

        super.method_25394(guiGraphics, mouseX, mouseY, partial);
        
        // Check if the browser texture is ready for rendering
        if (browser != null && browser.isTextureReady()) {
            renderBrowserTexture(guiGraphics);
        }

    }
    
    private void renderBrowserTexture(class_332 guiGraphics) {

        // Get the Identifier for the browser texture
        class_2960 textureLocation = browser.getTextureIdentifier();

        int frameRenderWidth = field_22789 - BROWSER_DRAW_OFFSET * 2;
        int frameRenderHeight = field_22790 - BROWSER_DRAW_OFFSET * 2;
        guiGraphics.method_25290(class_10799.field_56883, textureLocation, BROWSER_DRAW_OFFSET, BROWSER_DRAW_OFFSET, 0.0F, 0.0F, frameRenderWidth, frameRenderHeight, frameRenderWidth, frameRenderHeight);

    }

    @Override
    public boolean method_25402(class_11909 event, boolean isDoubleClick) {
        browser.sendMousePress(mouseX(event.comp_4798()), mouseY(event.comp_4799()), event.method_74245());
        browser.setFocus(true);
        return super.method_25402(event, isDoubleClick);
    }

    @Override
    public boolean method_25406(class_11909 event) {
        browser.sendMouseRelease(mouseX(event.comp_4798()), mouseY(event.comp_4799()), event.method_74245());
        browser.setFocus(true);
        return super.method_25406(event);
    }

    @Override
    public void method_16014(double mouseX, double mouseY) {
        browser.sendMouseMove(mouseX(mouseX), mouseY(mouseY));
        super.method_16014(mouseX, mouseY);
    }

    @Override
    public boolean method_25403(class_11909 event, double dragX, double dragY) {
        return super.method_25403(event, dragX, dragY);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        browser.sendMouseWheel(mouseX(mouseX), mouseY(mouseY), scrollY, 0);
        return super.method_25401(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    public boolean method_25404(class_11908 event) {
        browser.sendKeyPress(event.comp_4795(), event.comp_4796(), event.comp_4797());
        browser.setFocus(true);
        return super.method_25404(event);
    }

    @Override
    public boolean method_16803(class_11908 event) {
        browser.sendKeyRelease(event.comp_4795(), event.comp_4796(), event.comp_4797());
        browser.setFocus(true);
        return super.method_16803(event);
    }

    @Override
    public boolean method_25400(class_11905 event) {
        if (event.comp_4793() == (char) 0) return false;
        browser.sendKeyTyped((char) event.comp_4793(), event.comp_4794());
        browser.setFocus(true);
        return super.method_25400(event);
    }

}
