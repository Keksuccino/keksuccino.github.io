package com.cinemamod.mcef.mixins;

import com.cinemamod.mcef.MCEF;
import com.cinemamod.mcef.MCEFDownloader;
import com.cinemamod.mcef.MCEFPlatform;
import com.cinemamod.mcef.MCEFSettings;
import com.cinemamod.mcef.internal.MCEFDownloadListener;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import java.io.File;
import java.io.IOException;
import net.minecraft.class_1065;

/**
 * <p>
 * mcef.libraries.path is where MCEF will store any required binaries. By default,
 * /path/to/.minecraft/mods/mcef-libraries.
 * <p>
 * jcef.path is the location of the standard java-cef bundle. By default,
 * /path/to/mcef-libraries/<normalized platform name> where normalized platform name comes from
 * {@link MCEFPlatform#getNormalizedName()}. This is what java-cef uses internally to find the
 * installation. Also see {@link org.cef.CefApp}.
 */
@Mixin(class_1065.class)
public class MixinClientPackSource {

    @Inject(at = @At("HEAD"), method = "<clinit>")
    private static void sinit(CallbackInfo callbackInfo) {
        try {
            setupLibraryPath_MCEF();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Thread downloadThread = new Thread(() -> {
            String javaCefCommit;

            try {
                javaCefCommit = MCEF.getJavaCefCommit();
            } catch (IOException e) {
                e.printStackTrace();
                return;
            }

            MCEF.getLogger().info("java-cef commit: " + javaCefCommit);

            MCEFSettings settings = MCEF.getSettings();
            MCEFDownloader downloader = new MCEFDownloader(settings.getDownloadMirror(), javaCefCommit, MCEFPlatform.getPlatform());

            boolean downloadJcefBuild;

            // We always download the checksum for the java-cef build
            // We will compare this with mcef-libraries/<platform>.tar.gz.sha256
            // If the contents of the files differ (or it doesn't exist locally), we know we need to redownload JCEF
            try {
                downloadJcefBuild = !downloader.downloadJavaCefChecksum();
            } catch (IOException e) {
                MCEF.getLogger().error("Failed to download JCEF checksum.", e);
                MCEFDownloadListener.INSTANCE.setFailed(true);
                return;
            }

            // Ensure the mcef-libraries directory exists
            // If not, we want to try redownloading
            File mcefLibrariesDir = new File(System.getProperty("mcef.libraries.path"));
            downloadJcefBuild |= !mcefLibrariesDir.exists();

            if (downloadJcefBuild && !settings.isSkipDownload()) {
                try {
                    downloader.downloadJavaCefBuild();
                } catch (IOException e) {
                    MCEF.getLogger().error("Failed to download JCEF.", e);
                    MCEFDownloadListener.INSTANCE.setFailed(true);
                    return;
                }

                downloader.extractJavaCefBuild(true);
            }

            MCEFDownloadListener.INSTANCE.setDone(true);
        });
        downloadThread.start();
    }

    @Unique
    private static void setupLibraryPath_MCEF() throws IOException {
        final File mcefLibrariesDir;

        // Check for development environment
        // TODO: handle eclipse/others
        // i.e. mcef-repo/neoforge/build
        File buildDir = new File("../build");
        if (buildDir.exists() && buildDir.isDirectory()) {
            mcefLibrariesDir = new File(buildDir, "mcef-libraries/");
        } else {
            mcefLibrariesDir = new File("mods/mcef-libraries/");
        }

        mcefLibrariesDir.mkdirs();

        System.setProperty("mcef.libraries.path", mcefLibrariesDir.getCanonicalPath());
        System.setProperty("jcef.path", new File(mcefLibrariesDir, MCEFPlatform.getPlatform().getNormalizedName()).getCanonicalPath());
    }

}