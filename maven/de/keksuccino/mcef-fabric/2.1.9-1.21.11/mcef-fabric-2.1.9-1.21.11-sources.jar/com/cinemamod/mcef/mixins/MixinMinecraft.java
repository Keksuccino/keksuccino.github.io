package com.cinemamod.mcef.mixins;

import com.cinemamod.mcef.MCEF;
import com.cinemamod.mcef.MCEFPlatform;
import com.cinemamod.mcef.internal.MCEFDownloadListener;
import com.cinemamod.mcef.internal.MCEFDownloaderMenu;
import net.minecraft.class_310;
import net.minecraft.class_3928;
import net.minecraft.class_412;
import net.minecraft.class_413;
import net.minecraft.class_415;
import net.minecraft.class_420;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_4749;
import net.minecraft.class_500;
import net.minecraft.class_5235;
import net.minecraft.class_525;
import net.minecraft.class_526;
import net.minecraft.class_5375;
import net.minecraft.class_8032;
import net.minecraft.class_8134;
import net.minecraft.client.gui.screens.*;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.concurrent.atomic.AtomicBoolean;

@Mixin(class_310.class)
public abstract class MixinMinecraft {

    @Unique
    private static final AtomicBoolean RECURSION_DETECTOR_MCEF = new AtomicBoolean(false);

    @Shadow
    public abstract void setScreen(@Nullable class_437 screen);

    @Inject(method = "setScreen", at = @At("HEAD"), cancellable = true)
    public void head_setScreen_MCEF(class_437 screen, CallbackInfo info) {

        if (!MCEF.isInitialized()) {
            boolean recursionValue = RECURSION_DETECTOR_MCEF.get();
            RECURSION_DETECTOR_MCEF.set(true);

            // regardless of what screen the game opens to, MCEF must try to initialize
            // if it does not, there are bigger problems
            if (
                // mods may try to set the screen before the first screen opens
                // in the event that this happens, recursion would happen
                // so if this is detected, not try to open the screen again, as that could cause a crash
                    !recursionValue ||
                            screen instanceof class_442 ||
                            screen instanceof class_3928 ||
                            screen instanceof class_526 ||
                            screen instanceof class_420 ||
                            screen instanceof class_412 ||
                            screen instanceof class_8032 ||
                            screen instanceof class_4749 ||
                            screen instanceof class_500 ||
                            screen instanceof class_525 ||
                            screen instanceof class_5235 ||
                            screen instanceof class_8134 ||
                            screen instanceof class_5375 ||
                            screen instanceof class_413 ||
                            screen instanceof class_415
            ) {
                // If the download is done and didn't fail
                if (MCEFDownloadListener.INSTANCE.isDone() && !MCEFDownloadListener.INSTANCE.isFailed()) {
                    MCEF.getLogger().debug("MCEF already finished downloading, scheduling loading.");
                    class_310.method_1551().execute((() -> {
                        MCEF.getLogger().debug("MCEF is attempting to load.");
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            MCEF.getLogger().error("I don't even know what occurred here.", e);
                        }
                        MCEF.initialize();
                    }));
                }
                // If the download is not done and didn't fail
                else if (!MCEFDownloadListener.INSTANCE.isDone() && !MCEFDownloadListener.INSTANCE.isFailed()) {
                    MCEF.getLogger().debug("MCEF has not finished loading, displaying loading screen.");
                    setScreen(new MCEFDownloaderMenu(screen));
                    info.cancel();
                }
                // If the download failed
                else if (MCEFDownloadListener.INSTANCE.isFailed()) {
                    MCEF.getLogger().error("MCEF failed to initialize!");
                }
            }

            RECURSION_DETECTOR_MCEF.set(recursionValue);
        }

    }

    /**
     * Temporary workaround to address lingering JCEF processes on Windows.
     * @author Blobanium
     */
    @Inject(method = "close", at = @At("TAIL"))
    public void tail_close_MCEF(CallbackInfo info) {

        if (MCEFPlatform.getPlatform().isWindows()) {
            String processName = "jcef_helper.exe";
            try {
                ProcessBuilder processBuilder = new ProcessBuilder("tasklist");
                Process process = processBuilder.start();

                BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                String line;
                boolean isRunning = false;
                while ((line = reader.readLine()) != null) {
                    if (line.contains(processName)) {
                        isRunning = true;
                        break;
                    }
                }
                reader.close();

                if (isRunning) {
                    MCEF.getLogger().warn("JCEF is still running, killing to avoid lingering processes.");
                    ProcessBuilder killProcess = new ProcessBuilder("taskkill", "/F", "/IM", processName);
                    killProcess.start();
                }
            } catch (Exception e) {
                MCEF.getLogger().error("Unable to check if JCEF is still running. There may be lingering processes.", e);
            }
        }

    }

}
