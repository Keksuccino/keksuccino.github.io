package de.keksuccino.rinku;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import net.minecraft.class_1044;

/**
 * Texture wrapper that exposes an externally managed GPU texture to Minecraft's texture manager.
 */
public class RinkuDirectTexture extends class_1044 {

    private int width;
    private int height;

    public RinkuDirectTexture() {
    }

    /**
     * Bind this wrapper to an existing GPU texture managed by RinkuRenderer.
     *
     * @param textureSource The texture to expose to Minecraft's texture manager
     * @param width The width of the texture
     * @param height The height of the texture
     */
    public void bindTexture(GpuTexture textureSource, int width, int height) {
        if (this.field_60597 != null) {
            this.field_60597.close();
            this.field_60597 = null;
        }

        this.field_56974 = null;

        if (textureSource != null && !textureSource.isClosed() && width > 0 && height > 0) {
            this.field_56974 = textureSource;
            this.field_60597 = RenderSystem.getDevice().createTextureView(this.field_56974);
            this.width = width;
            this.height = height;
        } else {
            this.field_56974 = null;
            this.width = 0;
            this.height = 0;
        }
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public GpuTexture getBoundTexture() {
        return this.field_56974;
    }

    public boolean isTextureViewReady() {
        return this.field_56974 != null
                && !this.field_56974.isClosed()
                && this.field_60597 != null
                && !this.field_60597.isClosed();
    }

    @Override
    public void close() {
        if (this.field_60597 != null) {
            this.field_60597.close();
            this.field_60597 = null;
        }
        this.field_56974 = null;
        this.width = 0;
        this.height = 0;
    }

}
