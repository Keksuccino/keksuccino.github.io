package de.keksuccino.rinku;

import de.keksuccino.rinku.binarydownload.RinkuDownloader;
import org.cef.CefSettings;

import javax.annotation.Nullable;
import net.minecraft.class_10799;
import net.minecraft.class_11467;
import net.minecraft.class_11908;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_7842;
import net.minecraft.class_7847;
import net.minecraft.class_7919;
import net.minecraft.class_8021;
import net.minecraft.class_8030;
import net.minecraft.class_8087;
import net.minecraft.class_8088;
import net.minecraft.class_8089;
import net.minecraft.class_8132;
import net.minecraft.class_8667;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

/** Rinku's loader-independent, tabbed configuration screen. */
public class OptionsScreen extends class_437 {

    private static final int BUTTON_HEIGHT = 20;
    private static final int BUTTON_ROW_MAX_WIDTH = 360;
    private static final int EDITABLE_LABEL_WIDTH = 155;
    private static final int EDITABLE_ROW_GAP = 5;
    private static final int OPTION_ROW_ADVANCE = 26;
    private static final int OPTION_SECTION_PADDING_TOP = 10;
    private static final int CYCLE_VALUE_COLOR = 0xFFAA00;
    private static final int INVALID_TEXT_COLOR = 0xFFFF5555;
    private static final int BROWSER_TAB_INDEX = 0;
    private static final int DOWNLOADS_TAB_INDEX = 1;
    private static final class_2960 TAB_HEADER_BACKGROUND = class_2960.method_60656("textures/gui/tab_header_background.png");

    @Nullable
    private final class_437 parent;
    private final RinkuSettings settings;
    private class_8132 layout;
    private class_8088 tabManager;
    private final List<class_4185> fullWidthOptionButtons = new ArrayList<>();
    private final List<TextOptionControl<?>> textOptionControls = new ArrayList<>();
    private final Map<String, String> pendingTextValues = new HashMap<>();
    @Nullable
    private class_8089 tabNavigationBar;
    @Nullable
    private class_4185 transparentPoolSizeButton;
    @Nullable
    private class_4185 opaquePoolSizeButton;

    public OptionsScreen(@Nullable class_437 parent) {
        super(class_2561.method_43471("rinku.options"));
        this.parent = parent;
        this.settings = Rinku.getSettings();
        this.initializePendingTextValues();
    }

    @Override
    protected void method_25426() {
        // HeaderAndFooterLayout has no reset operation in 1.21.11, so widget rebuilds need fresh layout state.
        this.layout = new class_8132(this);
        this.tabManager = new class_8088(this::method_37063, this::method_37066);
        this.fullWidthOptionButtons.clear();
        this.textOptionControls.clear();
        this.transparentPoolSizeButton = null;
        this.opaquePoolSizeButton = null;

        OptionsTab browserTab = this.buildBrowserTab();
        OptionsTab downloadsTab = this.buildDownloadsTab();
        OptionsTab advancedTab = this.buildAdvancedTab();
        browserTab.seal();
        downloadsTab.seal();
        advancedTab.seal();
        this.tabNavigationBar = class_8089.method_48623(this.tabManager, this.field_22789).method_48631(browserTab, downloadsTab, advancedTab).method_48627();
        this.method_37063(this.tabNavigationBar);

        this.layout.method_48996(class_4185.method_46430(class_5244.field_24334, ignored -> this.method_25419()).method_46432(150).method_46431());
        this.layout.method_48206(widget -> {
            widget.method_48591(1);
            this.method_37063(widget);
        });

        this.updateOptionWidths();
        this.updatePreloadControls();
        this.tabNavigationBar.method_48987(BROWSER_TAB_INDEX, false);
        this.method_48640();
    }

    private void initializePendingTextValues() {
        this.pendingTextValues.put("user-agent", this.settings.getUserAgent() == null ? "" : this.settings.getUserAgent());
        this.pendingTextValues.put("download-mirror", this.settings.getDownloadMirror() == null ? "" : this.settings.getDownloadMirror());
        this.pendingTextValues.put("download-connect-timeout-ms", Integer.toString(this.settings.getDownloadConnectTimeoutMs()));
        this.pendingTextValues.put("download-read-timeout-ms", Integer.toString(this.settings.getDownloadReadTimeoutMs()));
        this.pendingTextValues.put("download-max-archive-bytes", Long.toString(this.settings.getDownloadMaxArchiveBytes()));
        this.pendingTextValues.put("download-max-checksum-bytes", Long.toString(this.settings.getDownloadMaxChecksumBytes()));
        this.pendingTextValues.put("download-max-extracted-bytes", Long.toString(this.settings.getDownloadMaxExtractedBytes()));
    }

    private OptionsTab buildBrowserTab() {
        OptionsTab tab = new OptionsTab(class_2561.method_43471("rinku.options.tab.browser"));
        this.addTextOption(tab, BROWSER_TAB_INDEX, new TextOption<>("user-agent", "rinku.options.user_agent", "rinku.options.user_agent.desc", 512, RinkuOptionsInput::parseUserAgent, this.settings::getUserAgent, this.settings::setUserAgent, class_2561.method_43471("rinku.options.validation.user_agent")));
        this.addFullWidthOption(tab, this.buildBooleanButton("rinku.options.use_cache", "rinku.options.use_cache.desc", this.settings::isUsingCache, this.settings::setUseCache));
        this.addFullWidthOption(tab, this.buildBooleanButton("rinku.options.enable_widevine", "rinku.options.enable_widevine.desc", this.settings::isEnableWidevineCdm, this.settings::setEnableWidevineCdm));
        this.addFullWidthOption(tab, this.buildPreloadEnabledButton(), optionSettings -> optionSettings.method_46471(OPTION_SECTION_PADDING_TOP));
        this.transparentPoolSizeButton = this.buildPoolSizeButton("rinku.options.preload_transparent_pool_size", "rinku.options.preload_transparent_pool_size.desc", this.settings::getBrowserPreloadTransparentPoolSize, this.settings::setBrowserPreloadTransparentPoolSize);
        this.opaquePoolSizeButton = this.buildPoolSizeButton("rinku.options.preload_opaque_pool_size", "rinku.options.preload_opaque_pool_size.desc", this.settings::getBrowserPreloadOpaquePoolSize, this.settings::setBrowserPreloadOpaquePoolSize);
        this.addFullWidthOption(tab, this.transparentPoolSizeButton);
        this.addFullWidthOption(tab, this.opaquePoolSizeButton);
        return tab;
    }

    private OptionsTab buildDownloadsTab() {
        OptionsTab tab = new OptionsTab(class_2561.method_43471("rinku.options.tab.downloads"));
        this.addFullWidthOption(tab, this.buildBooleanButton("rinku.options.skip_download", "rinku.options.skip_download.desc", this.settings::isSkipDownload, this.settings::setSkipDownload));
        this.addFullWidthOption(tab, this.buildMirrorPolicyButton());
        this.addTextOption(tab, DOWNLOADS_TAB_INDEX, new TextOption<>("download-mirror", "rinku.options.download_mirror", "rinku.options.download_mirror.desc", 2048, this::parseDownloadMirror, this.settings::getDownloadMirror, this.settings::setDownloadMirror, class_2561.method_43471("rinku.options.validation.download_mirror")));
        this.addFullWidthOption(tab, this.buildBooleanButton("rinku.options.enforce_checksums", "rinku.options.enforce_checksums.desc", this.settings::isEnforceDownloadChecksums, this.settings::setEnforceDownloadChecksums));
        this.addTextOption(tab, DOWNLOADS_TAB_INDEX, new TextOption<>("download-connect-timeout-ms", "rinku.options.connect_timeout", "rinku.options.connect_timeout.desc", 6, value -> RinkuOptionsInput.parseInt(value, RinkuSettings.MIN_DOWNLOAD_TIMEOUT_MS, RinkuSettings.MAX_DOWNLOAD_TIMEOUT_MS), this.settings::getDownloadConnectTimeoutMs, this.settings::setDownloadConnectTimeoutMs, class_2561.method_43469("rinku.options.validation.integer_range", RinkuSettings.MIN_DOWNLOAD_TIMEOUT_MS, RinkuSettings.MAX_DOWNLOAD_TIMEOUT_MS)));
        this.addTextOption(tab, DOWNLOADS_TAB_INDEX, new TextOption<>("download-read-timeout-ms", "rinku.options.read_timeout", "rinku.options.read_timeout.desc", 6, value -> RinkuOptionsInput.parseInt(value, RinkuSettings.MIN_DOWNLOAD_TIMEOUT_MS, RinkuSettings.MAX_DOWNLOAD_TIMEOUT_MS), this.settings::getDownloadReadTimeoutMs, this.settings::setDownloadReadTimeoutMs, class_2561.method_43469("rinku.options.validation.integer_range", RinkuSettings.MIN_DOWNLOAD_TIMEOUT_MS, RinkuSettings.MAX_DOWNLOAD_TIMEOUT_MS)));
        this.addTextOption(tab, DOWNLOADS_TAB_INDEX, new TextOption<>("download-max-archive-bytes", "rinku.options.max_archive_bytes", "rinku.options.max_archive_bytes.desc", 10, value -> RinkuOptionsInput.parseLong(value, RinkuSettings.MIN_DOWNLOAD_ARCHIVE_BYTES, RinkuSettings.MAX_DOWNLOAD_ARCHIVE_BYTES), this.settings::getDownloadMaxArchiveBytes, this.settings::setDownloadMaxArchiveBytes, class_2561.method_43469("rinku.options.validation.integer_range", RinkuSettings.MIN_DOWNLOAD_ARCHIVE_BYTES, RinkuSettings.MAX_DOWNLOAD_ARCHIVE_BYTES)));
        this.addTextOption(tab, DOWNLOADS_TAB_INDEX, new TextOption<>("download-max-checksum-bytes", "rinku.options.max_checksum_bytes", "rinku.options.max_checksum_bytes.desc", 7, value -> RinkuOptionsInput.parseLong(value, RinkuSettings.MIN_DOWNLOAD_CHECKSUM_BYTES, RinkuSettings.MAX_DOWNLOAD_CHECKSUM_BYTES), this.settings::getDownloadMaxChecksumBytes, this.settings::setDownloadMaxChecksumBytes, class_2561.method_43469("rinku.options.validation.integer_range", RinkuSettings.MIN_DOWNLOAD_CHECKSUM_BYTES, RinkuSettings.MAX_DOWNLOAD_CHECKSUM_BYTES)));
        this.addTextOption(tab, DOWNLOADS_TAB_INDEX, new TextOption<>("download-max-extracted-bytes", "rinku.options.max_extracted_bytes", "rinku.options.max_extracted_bytes.desc", 11, value -> RinkuOptionsInput.parseLong(value, RinkuSettings.MIN_DOWNLOAD_EXTRACTED_BYTES, RinkuSettings.MAX_DOWNLOAD_EXTRACTED_BYTES), this.settings::getDownloadMaxExtractedBytes, this.settings::setDownloadMaxExtractedBytes, class_2561.method_43469("rinku.options.validation.integer_range", RinkuSettings.MIN_DOWNLOAD_EXTRACTED_BYTES, RinkuSettings.MAX_DOWNLOAD_EXTRACTED_BYTES)));
        return tab;
    }

    private OptionsTab buildAdvancedTab() {
        OptionsTab tab = new OptionsTab(class_2561.method_43471("rinku.options.tab.advanced"));
        this.addFullWidthOption(tab, this.buildBooleanButton("rinku.options.disable_web_security", "rinku.options.disable_web_security.desc", this.settings::isDisableWebSecurity, this.settings::setDisableWebSecurity));
        this.addFullWidthOption(tab, this.buildLogSeverityButton("rinku.options.native_log_severity", "rinku.options.native_log_severity.desc", this.settings::getNativeCefLogSeverity, this.settings::setNativeCefLogSeverity));
        this.addFullWidthOption(tab, this.buildLogSeverityButton("rinku.options.console_log_severity", "rinku.options.console_log_severity.desc", this.settings::getConsoleLogForwardingMinSeverity, this.settings::setConsoleLogForwardingMinSeverity));
        return tab;
    }

    private class_4185 buildPreloadEnabledButton() {
        class_4185 button = class_4185.method_46430(this.booleanOptionMessage("rinku.options.preload_enabled", this.settings.isBrowserPreloadEnabled()), pressedButton -> {
            this.settings.setBrowserPreloadEnabled(!this.settings.isBrowserPreloadEnabled());
            pressedButton.method_25355(this.booleanOptionMessage("rinku.options.preload_enabled", this.settings.isBrowserPreloadEnabled()));
            this.updatePreloadControls();
        }).method_46432(this.getButtonWidth()).method_46436(class_7919.method_47407(class_2561.method_43471("rinku.options.preload_enabled.desc"))).method_46431();
        return button;
    }

    private class_4185 buildMirrorPolicyButton() {
        class_4185 button = class_4185.method_46430(this.mirrorPolicyMessage(), pressedButton -> {
            this.settings.setDownloadMirrorPolicy(nextValue(this.settings.getDownloadMirrorPolicy(), RinkuDownloader.MirrorPolicy.values()));
            pressedButton.method_25355(this.mirrorPolicyMessage());
            this.validateTextOptions();
        }).method_46432(this.getButtonWidth()).method_46436(class_7919.method_47407(class_2561.method_43471("rinku.options.download_mirror_policy.desc"))).method_46431();
        return button;
    }

    private class_4185 buildLogSeverityButton(String labelKey, String descriptionKey, Supplier<CefSettings.LogSeverity> getter, Consumer<CefSettings.LogSeverity> setter) {
        class_4185 button = class_4185.method_46430(this.logSeverityMessage(labelKey, getter.get()), pressedButton -> {
            CefSettings.LogSeverity next = nextValue(getter.get(), CefSettings.LogSeverity.values());
            setter.accept(next);
            pressedButton.method_25355(this.logSeverityMessage(labelKey, next));
        }).method_46432(this.getButtonWidth()).method_46436(class_7919.method_47407(class_2561.method_43471(descriptionKey))).method_46431();
        return button;
    }

    private class_4185 buildPoolSizeButton(String labelKey, String descriptionKey, Supplier<Integer> getter, Consumer<Integer> setter) {
        class_4185 button = class_4185.method_46430(this.integerOptionMessage(labelKey, getter.get()), pressedButton -> {
            int next = getter.get() >= RinkuSettings.MAX_BROWSER_PRELOAD_POOL_SIZE ? RinkuSettings.MIN_BROWSER_PRELOAD_POOL_SIZE : getter.get() + 1;
            setter.accept(next);
            pressedButton.method_25355(this.integerOptionMessage(labelKey, next));
        }).method_46432(this.getButtonWidth()).method_46436(class_7919.method_47407(class_2561.method_43471(descriptionKey))).method_46431();
        return button;
    }

    private class_4185 buildBooleanButton(String labelKey, String descriptionKey, Supplier<Boolean> getter, Consumer<Boolean> setter) {
        class_4185 button = class_4185.method_46430(this.booleanOptionMessage(labelKey, getter.get()), pressedButton -> {
            boolean next = !getter.get();
            setter.accept(next);
            pressedButton.method_25355(this.booleanOptionMessage(labelKey, next));
        }).method_46432(this.getButtonWidth()).method_46436(class_7919.method_47407(class_2561.method_43471(descriptionKey))).method_46431();
        return button;
    }

    private void addFullWidthOption(OptionsTab tab, class_4185 button) {
        this.fullWidthOptionButtons.add(button);
        tab.addChild(button);
    }

    private void addFullWidthOption(OptionsTab tab, class_4185 button, Consumer<class_7847> layoutSettings) {
        this.fullWidthOptionButtons.add(button);
        tab.addChild(button, layoutSettings);
    }

    private <T> void addTextOption(OptionsTab tab, int tabIndex, TextOption<T> option) {
        class_2561 label = class_2561.method_43471(option.labelKey());
        class_2561 description = class_2561.method_43471(option.descriptionKey());
        class_7842 labelWidget = new class_7842(EDITABLE_LABEL_WIDTH, BUTTON_HEIGHT, label, this.field_22793);
        class_342 editBox = new class_342(this.field_22793, this.getButtonWidth() - EDITABLE_LABEL_WIDTH - EDITABLE_ROW_GAP, BUTTON_HEIGHT, label);
        String initialValue = this.pendingTextValues.getOrDefault(option.id(), "");
        labelWidget.method_47400(class_7919.method_47407(description));
        // Never truncate a longer value loaded from disk merely because the screen was opened.
        editBox.method_1880(Math.max(option.maxLength(), initialValue.length()));
        editBox.method_1852(initialValue);
        editBox.method_47400(class_7919.method_47407(description));
        TextOptionControl<T> control = new TextOptionControl<>(tabIndex, option, labelWidget, editBox, description);
        editBox.method_1863(value -> {
            this.pendingTextValues.put(option.id(), value);
            control.validate();
        });
        this.textOptionControls.add(control);
        class_8667 row = class_8667.method_52742().method_52735(EDITABLE_ROW_GAP);
        row.method_52736(labelWidget);
        row.method_52736(editBox);
        tab.addChild(row);
    }

    private String parseDownloadMirror(String value) {
        return RinkuOptionsInput.parseMirror(value, this.settings.getDownloadMirrorPolicy() != RinkuDownloader.MirrorPolicy.CONFIGURED_ONLY);
    }

    private void updatePreloadControls() {
        boolean active = this.settings.isBrowserPreloadEnabled();
        if (this.transparentPoolSizeButton != null) this.transparentPoolSizeButton.field_22763 = active;
        if (this.opaquePoolSizeButton != null) this.opaquePoolSizeButton.field_22763 = active;
    }

    private void updateOptionWidths() {
        int rowWidth = this.getButtonWidth();
        for (class_4185 button : this.fullWidthOptionButtons) button.method_25358(rowWidth);
        int labelWidth = Math.min(EDITABLE_LABEL_WIDTH, Math.max(80, rowWidth / 2));
        for (TextOptionControl<?> control : this.textOptionControls) {
            control.label().method_25358(labelWidth);
            control.editBox().method_25358(Math.max(40, rowWidth - labelWidth - EDITABLE_ROW_GAP));
        }
    }

    private void validateTextOptions() {
        for (TextOptionControl<?> control : this.textOptionControls) control.validate();
    }

    private boolean applyTextOptions() {
        TextOptionControl<?> firstInvalid = null;
        for (TextOptionControl<?> control : this.textOptionControls) {
            if (!control.validate() && firstInvalid == null) firstInvalid = control;
        }
        if (firstInvalid != null) {
            if (this.tabNavigationBar != null) this.tabNavigationBar.method_48987(firstInvalid.tabIndex(), false);
            return false;
        }
        for (TextOptionControl<?> control : this.textOptionControls) control.applyParsedValue();
        return true;
    }

    private class_2561 booleanOptionMessage(String labelKey, boolean enabled) {
        class_2561 value = class_2561.method_43471(enabled ? "rinku.options.toggle.enabled" : "rinku.options.toggle.disabled").method_27696(class_2583.field_24360.method_10977(enabled ? class_124.field_1060 : class_124.field_1061));
        return class_2561.method_43469(labelKey, value);
    }

    private class_2561 integerOptionMessage(String labelKey, int value) {
        return class_2561.method_43469(labelKey, this.cycleValue(class_2561.method_43470(Integer.toString(value))));
    }

    private class_2561 mirrorPolicyMessage() {
        String valueKey = "rinku.options.download_mirror_policy." + this.settings.getDownloadMirrorPolicy().name().toLowerCase(java.util.Locale.ROOT);
        return class_2561.method_43469("rinku.options.download_mirror_policy", this.cycleValue(class_2561.method_43471(valueKey)));
    }

    private class_2561 logSeverityMessage(String labelKey, CefSettings.LogSeverity severity) {
        String severityName = severity.name().substring("LOGSEVERITY_".length()).toLowerCase(java.util.Locale.ROOT);
        return class_2561.method_43469(labelKey, this.cycleValue(class_2561.method_43471("rinku.options.log_severity." + severityName)));
    }

    private class_2561 cycleValue(class_2561 value) {
        return value.method_27661().method_27696(class_2583.field_24360.method_36139(CYCLE_VALUE_COLOR));
    }

    private int getButtonWidth() {
        return Math.min(BUTTON_ROW_MAX_WIDTH, this.field_22789 - 40);
    }

    private static <T> T nextValue(T current, T[] values) {
        for (int index = 0; index < values.length; index++) {
            if (values[index] == current) return values[(index + 1) % values.length];
        }
        return values[0];
    }

    @Override
    public boolean method_25404(class_11908 event) {
        if (this.tabNavigationBar != null && this.tabNavigationBar.method_25404(event)) return true;
        return super.method_25404(event);
    }

    @Override
    protected void method_48640() {
        if (this.tabNavigationBar == null) return;
        this.tabNavigationBar.method_48618(this.field_22789);
        this.tabNavigationBar.method_49613();
        int tabAreaTop = this.tabNavigationBar.method_48202().method_49619();
        class_8030 tabArea = new class_8030(0, tabAreaTop, this.field_22789, Math.max(0, this.field_22790 - this.layout.method_48994() - tabAreaTop));
        this.tabManager.method_48616(tabArea);
        this.layout.method_48995(tabAreaTop);
        this.layout.method_48222();
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(graphics, mouseX, mouseY, partialTick);
        graphics.method_25290(class_10799.field_56883, class_437.field_49896, 0, this.field_22790 - this.layout.method_48994(), 0.0F, 0.0F, this.field_22789, 2, 32, 2);
    }

    @Override
    protected void method_57735(class_332 graphics) {
        graphics.method_25290(class_10799.field_56883, TAB_HEADER_BACKGROUND, 0, 0, 0.0F, 0.0F, this.field_22789, this.layout.method_48998(), 16, 16);
        this.method_57736(graphics, 0, this.layout.method_48998(), this.field_22789, this.field_22790);
    }

    @Override
    public void method_25419() {
        if (!this.applyTextOptions()) return;
        class_310.method_1551().method_1507(this.parent);
    }

    private record TextOption<T>(String id, String labelKey, String descriptionKey, int maxLength, Function<String, T> parser, Supplier<T> currentValue, Consumer<T> applier, class_2561 invalidMessage) {
    }

    private final class TextOptionControl<T> {

        private final int tabIndex;
        private final TextOption<T> option;
        private final class_7842 label;
        private final class_342 editBox;
        private final class_2561 description;
        @Nullable
        private T parsedValue;

        private TextOptionControl(int tabIndex, TextOption<T> option, class_7842 label, class_342 editBox, class_2561 description) {
            this.tabIndex = tabIndex;
            this.option = option;
            this.label = label;
            this.editBox = editBox;
            this.description = description;
        }

        private boolean validate() {
            try {
                this.parsedValue = this.option.parser().apply(this.editBox.method_1882());
                this.editBox.method_1868(class_342.field_32196);
                this.editBox.method_47400(class_7919.method_47407(this.description));
                return true;
            } catch (IllegalArgumentException exception) {
                this.parsedValue = null;
                this.editBox.method_1868(INVALID_TEXT_COLOR);
                this.editBox.method_47400(class_7919.method_47407(this.option.invalidMessage()));
                return false;
            }
        }

        private void applyParsedValue() {
            if (!Objects.equals(this.parsedValue, this.option.currentValue().get())) this.option.applier().accept(this.parsedValue);
        }

        private int tabIndex() {
            return this.tabIndex;
        }

        private class_7842 label() {
            return this.label;
        }

        private class_342 editBox() {
            return this.editBox;
        }

    }

    private final class OptionsTab implements class_8087 {

        private final class_2561 title;
        private final class_8667 optionsLayout;
        @Nullable
        private class_11467 scrollableLayout;
        private boolean sealed;

        private OptionsTab(class_2561 title) {
            this.title = title;
            this.optionsLayout = class_8667.method_52741().method_52735(OPTION_ROW_ADVANCE - BUTTON_HEIGHT);
            this.optionsLayout.method_52740().method_46467();
        }

        private void addChild(class_8021 child) {
            this.ensureMutable();
            this.optionsLayout.method_52736(child);
        }

        private void addChild(class_8021 child, Consumer<class_7847> settings) {
            this.ensureMutable();
            this.optionsLayout.method_52738(child, settings);
        }

        private void seal() {
            if (this.sealed) return;
            this.sealed = true;
            // 1.21.11 captures the content widget list inside ScrollableLayout's constructor. Constructing
            // it before every option is added silently produces an empty tab even though the layout has children.
            this.scrollableLayout = new class_11467(OptionsScreen.this.field_22787, this.optionsLayout, BUTTON_HEIGHT);
        }

        private void ensureMutable() {
            if (this.sealed) throw new IllegalStateException("Cannot add options after the scrollable tab has been sealed.");
        }

        private class_11467 getScrollableLayout() {
            if (this.scrollableLayout == null) throw new IllegalStateException("Options tab must be sealed before it is displayed.");
            return this.scrollableLayout;
        }

        @Override
        public class_2561 method_48610() {
            return this.title;
        }

        @Override
        public class_2561 method_71245() {
            return class_2561.method_43473();
        }

        @Override
        public void method_48612(Consumer<class_339> childrenConsumer) {
            // ScrollableLayout caches content widgets; arrange before TabManager registers the container.
            class_11467 scrollableLayout = this.getScrollableLayout();
            scrollableLayout.method_48222();
            scrollableLayout.method_48206(childrenConsumer);
        }

        @Override
        public void method_48611(class_8030 screenRectangle) {
            OptionsScreen.this.updateOptionWidths();
            int topY = Math.max(screenRectangle.method_49618() + 4, Math.min(50, screenRectangle.method_49619() - BUTTON_HEIGHT));
            class_11467 scrollableLayout = this.getScrollableLayout();
            scrollableLayout.method_71806(OptionsScreen.this.getButtonWidth());
            scrollableLayout.method_48222();
            scrollableLayout.method_71807(Math.max(BUTTON_HEIGHT, screenRectangle.method_49619() - topY));
            scrollableLayout.method_48229((OptionsScreen.this.field_22789 - scrollableLayout.method_25368()) / 2, topY);
        }

    }

}
