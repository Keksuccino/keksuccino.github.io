package de.keksuccino.rinku.mixins;

import com.mojang.logging.LogUtils;
import de.keksuccino.rinku.OSPlatform;
import de.keksuccino.rinku.Rinku;
import de.keksuccino.rinku.RinkuRenderCoordinator;
import de.keksuccino.rinku.binarydownload.RinkuDownloadListener;
import de.keksuccino.rinku.binarydownload.RinkuDownloaderScreen;
import de.keksuccino.rinku.lifecycle.ClientInitializationReadinessController;
import de.keksuccino.rinku.platform.Services;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.io.IOException;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.util.Locale;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.class_310;
import net.minecraft.class_3928;
import net.minecraft.class_412;
import net.minecraft.class_413;
import net.minecraft.class_415;
import net.minecraft.class_420;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_4749;
import net.minecraft.class_500;
import net.minecraft.class_5235;
import net.minecraft.class_525;
import net.minecraft.class_526;
import net.minecraft.class_5375;
import net.minecraft.class_8032;
import net.minecraft.class_8134;

@Mixin(class_310.class)
public abstract class MixinMinecraft {
    @Shadow public abstract void setScreen(@Nullable class_437 screen);

    @Unique private static final Logger LOGGER_RINKU = LogUtils.getLogger();
    @Unique private static final AtomicBoolean RECURSION_DETECTOR_RINKU = new AtomicBoolean(false);
    @Unique private static final AtomicBoolean INITIALIZATION_SCHEDULED_RINKU = new AtomicBoolean(false);
    @Unique private static final ClientInitializationReadinessController CLIENT_INITIALIZATION_READINESS_RINKU = new ClientInitializationReadinessController();
    @Unique private static final String JCEF_HELPER_EXECUTABLE_WINDOWS_RINKU = "jcef_helper.exe";

    @Inject(method = "setScreen", at = @At("HEAD"), cancellable = true)
    private void before_setScreen_Rinku(@Nullable class_437 screen, CallbackInfo info) {
        if (!Rinku.isInitializationAllowed()) return;
        if (CLIENT_INITIALIZATION_READINESS_RINKU.shouldDeferInitialization(Services.PLATFORM.requiresClientInitializationDeferral())) return;
        if (handleScreenChangeWithRecursion_Rinku(screen)) info.cancel();
    }

    // Keep this as a direct frame hook: Minecraft may discard queued executor tasks during shutdown.
    @Inject(method = "runTick", at = @At("HEAD"))
    private void before_runTick_Rinku(boolean advanceGameTime, CallbackInfo info) {
        RinkuRenderCoordinator.pumpOnRenderThread();
        class_310 minecraft = (class_310) (Object) this;
        boolean requiresDeferral = Services.PLATFORM.requiresClientInitializationDeferral();
        boolean stableCandidate = Services.PLATFORM.isClientInitializationCandidateReady() && minecraft.method_53466() && minecraft.method_18506() == null && minecraft.field_1755 != null;
        boolean retryInitialization = CLIENT_INITIALIZATION_READINESS_RINKU.observeTick(requiresDeferral, stableCandidate);
        if (retryInitialization && Rinku.isInitializationAllowed()) {
            handleScreenChangeWithRecursion_Rinku(minecraft.field_1755);
        }
    }

    // Drain and close browser GPU resources before vanilla tears down the render device and GL context.
    @Inject(method = "close", at = @At("HEAD"))
    private void before_close_Rinku(CallbackInfo info) {
        RinkuRenderCoordinator.shutdownOnRenderThread();
        Rinku.shutdown();
    }

    /**
     * Temporary workaround to address lingering JCEF processes on Windows.
     * @author Blobanium
     */
    @Inject(method = "close", at = @At("TAIL"))
    private void after_close_Rinku(CallbackInfo info) {

        if (!OSPlatform.getPlatform().isWindows()) {
            return;
        }

        Path rinkuLibrariesPath = resolveRinkuLibrariesPath_Rinku();
        if (rinkuLibrariesPath == null) {
            LOGGER_RINKU.warn("rinku.libraries.path is not set, skipping scoped JCEF helper cleanup.");
            return;
        }

        AtomicInteger terminatedProcesses = new AtomicInteger(0);
        try {
            ProcessHandle.allProcesses().forEach(processHandle -> {
                try {
                    if (!shouldTerminateJcefHelper_Rinku(processHandle, rinkuLibrariesPath)) {
                        return;
                    }

                    if (terminateProcess_Rinku(processHandle)) {
                        terminatedProcesses.incrementAndGet();
                        LOGGER_RINKU.warn("Terminated lingering JCEF helper process (pid={}).", processHandle.pid());
                    }
                } catch (Exception e) {
                    LOGGER_RINKU.debug("Unable to inspect process {} for scoped JCEF cleanup.", processHandle.pid(), e);
                }
            });
        } catch (Exception e) {
            LOGGER_RINKU.error("Unable to enumerate processes for scoped JCEF cleanup.", e);
            return;
        }

        if (terminatedProcesses.get() > 0) {
            LOGGER_RINKU.warn("Terminated {} lingering JCEF helper process(es) under {}.",
                    terminatedProcesses.get(), rinkuLibrariesPath);
        }

    }

    @Unique
    private boolean handleScreenChangeWithRecursion_Rinku(@Nullable class_437 screen) {
        boolean recursionValue = RECURSION_DETECTOR_RINKU.get();
        RECURSION_DETECTOR_RINKU.set(true);
        try {
            return handleScreenChange_Rinku(screen, recursionValue);
        } finally {
            RECURSION_DETECTOR_RINKU.set(recursionValue);
        }
    }

    @Unique
    private boolean handleScreenChange_Rinku(@Nullable class_437 screen, boolean recursionValue) {
        if (!Rinku.isInitializationAllowed() || !shouldHandleScreenChange_Rinku(screen, recursionValue)) return false;
        if (RinkuDownloadListener.INSTANCE.isDone() && !RinkuDownloadListener.INSTANCE.isFailed()) {
            scheduleInitialization_Rinku();
            return false;
        }
        if (!RinkuDownloadListener.INSTANCE.isDone() && !RinkuDownloadListener.INSTANCE.isFailed()) {
            LOGGER_RINKU.debug("Rinku has not finished loading, displaying loading screen.");
            this.setScreen(new RinkuDownloaderScreen(screen));
            return true;
        }
        LOGGER_RINKU.error("Rinku failed to initialize!");
        return false;
    }

    @Unique
    private static void scheduleInitialization_Rinku() {
        if (!INITIALIZATION_SCHEDULED_RINKU.compareAndSet(false, true)) return;
        LOGGER_RINKU.debug("Rinku finished downloading; scheduling one initialization attempt.");
        class_310.method_1551().execute(() -> {
            if (!Rinku.isInitializationAllowed()) return;
            LOGGER_RINKU.debug("Rinku is attempting to load after the client readiness gate.");
            Rinku.initialize();
        });
    }

    @Unique
    private static boolean shouldHandleScreenChange_Rinku(@Nullable class_437 screen, boolean recursionValue) {
        // Mods may open screens before the first vanilla screen. During that recursive replacement, only
        // known startup and joining screens are intercepted so unrelated mod screens cannot recurse forever.
        return !recursionValue
                || screen instanceof class_442
                || screen instanceof class_3928
                || screen instanceof class_526
                || screen instanceof class_420
                || screen instanceof class_412
                || screen instanceof class_8032
                || screen instanceof class_4749
                || screen instanceof class_500
                || screen instanceof class_525
                || screen instanceof class_5235
                || screen instanceof class_8134
                || screen instanceof class_5375
                || screen instanceof class_413
                || screen instanceof class_415;
    }

    @Unique
    private static boolean shouldTerminateJcefHelper_Rinku(ProcessHandle processHandle, Path rinkuLibrariesPath) {
        if (!processHandle.isAlive() || processHandle.pid() == ProcessHandle.current().pid()) {
            return false;
        }

        if (!isJcefHelperProcess_Rinku(processHandle)) {
            return false;
        }

        if (isExecutableInRinkuLibraries_Rinku(processHandle, rinkuLibrariesPath)) {
            return true;
        }

        // Fallback for environments where executable path is unavailable.
        return isDescendantOfCurrentProcess_Rinku(processHandle) && commandLineContainsLibrariesPath_Rinku(processHandle, rinkuLibrariesPath);
    }

    @Unique
    private static boolean terminateProcess_Rinku(ProcessHandle processHandle) {
        if (!processHandle.isAlive()) {
            return false;
        }

        if (processHandle.destroy()) {
            return true;
        }

        return processHandle.isAlive() && processHandle.destroyForcibly();
    }

    @Unique
    private static boolean isJcefHelperProcess_Rinku(ProcessHandle processHandle) {
        if (processHandle.info().command().map(MixinMinecraft::isJcefHelperExecutableName_Rinku).orElse(false)) {
            return true;
        }

        return processHandle.info().commandLine()
                .map(commandLine -> commandLine.toLowerCase(Locale.ROOT).contains(JCEF_HELPER_EXECUTABLE_WINDOWS_RINKU))
                .orElse(false);
    }

    @Unique
    private static boolean isJcefHelperExecutableName_Rinku(String command) {
        int lastSeparatorIndex = Math.max(command.lastIndexOf('/'), command.lastIndexOf('\\'));
        String executableName = lastSeparatorIndex >= 0 ? command.substring(lastSeparatorIndex + 1) : command;
        return executableName.equalsIgnoreCase(JCEF_HELPER_EXECUTABLE_WINDOWS_RINKU);
    }

    @Unique
    private static boolean isExecutableInRinkuLibraries_Rinku(ProcessHandle processHandle, Path rinkuLibrariesPath) {
        Optional<String> command = processHandle.info().command();
        if (command.isEmpty()) {
            return false;
        }

        try {
            Path commandPath = Path.of(command.get()).normalize();
            if (!commandPath.isAbsolute()) {
                return false;
            }
            return commandPath.startsWith(rinkuLibrariesPath);
        } catch (InvalidPathException ignored) {
            return false;
        }
    }

    @Unique
    private static boolean commandLineContainsLibrariesPath_Rinku(ProcessHandle processHandle, Path rinkuLibrariesPath) {
        String librariesPath = rinkuLibrariesPath.toString().toLowerCase(Locale.ROOT);
        return processHandle.info().commandLine()
                .map(commandLine -> commandLine.toLowerCase(Locale.ROOT).contains(librariesPath))
                .orElse(false);
    }

    @Unique
    private static boolean isDescendantOfCurrentProcess_Rinku(ProcessHandle processHandle) {
        long currentPid = ProcessHandle.current().pid();

        Optional<ProcessHandle> currentParent = processHandle.parent();
        while (currentParent.isPresent()) {
            ProcessHandle parent = currentParent.get();
            if (parent.pid() == currentPid) {
                return true;
            }
            currentParent = parent.parent();
        }

        return false;
    }

    @Unique
    private static @Nullable Path resolveRinkuLibrariesPath_Rinku() {
        String configuredPath = System.getProperty("rinku.libraries.path");
        if (configuredPath == null || configuredPath.isBlank()) {
            return null;
        }

        try {
            return Path.of(configuredPath).toRealPath().normalize();
        } catch (IOException | InvalidPathException e) {
            try {
                return Path.of(configuredPath).toAbsolutePath().normalize();
            } catch (InvalidPathException ignored) {
                return null;
            }
        }
    }

}
