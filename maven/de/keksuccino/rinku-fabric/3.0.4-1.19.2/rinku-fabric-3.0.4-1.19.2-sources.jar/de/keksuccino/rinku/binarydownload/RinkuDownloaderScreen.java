package de.keksuccino.rinku.binarydownload;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class RinkuDownloaderScreen extends class_437 {

    @Nullable
    private final class_437 parent;

    public RinkuDownloaderScreen(@Nullable class_437 parent) {
        super(class_2561.method_43471("rinku.downloader.title").method_27692(class_124.field_1065));
        this.parent = parent;
    }

    @Override
    public void method_25394(@NotNull class_4587 poseStack, int mouseX, int mouseY, float partialTick) {
        this.method_25420(poseStack);
        double centerX = this.field_22789 / 2.0D;
        double centerY = this.field_22790 / 2.0D;
        double progressBarHeight = 14.0D;
        double progressBarWidth = this.field_22789 / 3.0D;

        poseStack.method_22903();
        poseStack.method_22904(centerX - progressBarWidth / 2.0D, centerY - progressBarHeight / 2.0D, 0.0D);
        method_25294(poseStack, 0, 0, (int) progressBarWidth, (int) progressBarHeight, -1);
        method_25294(poseStack, 2, 2, (int) progressBarWidth - 2, (int) progressBarHeight - 2, -16777215);
        method_25294(poseStack, 4, 4, (int) ((progressBarWidth - 4.0D) * RinkuDownloadListener.INSTANCE.getProgress()), (int) progressBarHeight - 4, -1);
        poseStack.method_22909();

        class_2561[] lines = new class_2561[]{RinkuDownloadListener.INSTANCE.getTask(), class_2561.method_43469("rinku.downloader.progress", Math.round(RinkuDownloadListener.INSTANCE.getProgress() * 100.0D))};
        int offset = this.field_22793.field_2000 / 2 + (this.field_22793.field_2000 + 2) * (lines.length + 2) + 4;
        poseStack.method_22903();
        poseStack.method_22904(centerX, centerY - offset, 0.0D);
        method_27535(poseStack, this.field_22793, this.field_22785, -(this.field_22793.method_27525(this.field_22785) / 2), 0, -1);
        int lineY = this.field_22793.field_2000 + 2;
        for (class_2561 line : lines) {
            method_27535(poseStack, this.field_22793, line, -(this.field_22793.method_27525(line) / 2), lineY, -1);
            lineY += this.field_22793.field_2000 + 2;
        }
        poseStack.method_22909();
        super.method_25394(poseStack, mouseX, mouseY, partialTick);
    }

    @Override
    public void method_25393() {
        if (RinkuDownloadListener.INSTANCE.isDone() || RinkuDownloadListener.INSTANCE.isFailed()) class_310.method_1551().method_1507(this.parent);
    }

    @Override
    public boolean method_25422() {
        return false;
    }

    @Override
    public boolean method_25421() {
        return true;
    }

}
