package de.keksuccino.rinku;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.Objects;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4587;

/** Draws browser textures with the blend convention required by CEF's premultiplied OSR pixels. */
public final class RinkuBrowserTextureBlitter {

    private RinkuBrowserTextureBlitter() {
    }

    public static void blit(class_4587 poseStack, RinkuBrowser browser, int x, int y, int width, int height) {
        Objects.requireNonNull(poseStack, "poseStack");
        Objects.requireNonNull(browser, "browser");
        RinkuRenderer renderer = browser.getRenderer();
        class_2960 textureLocation = browser.getTextureIdentifier();
        int textureWidth = renderer.getTextureWidth();
        int textureHeight = renderer.getTextureHeight();
        if (textureLocation == null || textureWidth <= 0 || textureHeight <= 0 || width <= 0 || height <= 0) return;

        boolean transparent = renderer.isTransparent();
        try {
            beginBrowserDraw(transparent, NativeBlendStateAccess.INSTANCE);
            RenderSystem.setShaderTexture(0, textureLocation);
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
            class_332.method_25293(poseStack, x, y, width, height, 0.0F, 0.0F, textureWidth, textureHeight, textureWidth, textureHeight);
        } finally {
            finishBrowserDraw(transparent, NativeBlendStateAccess.INSTANCE);
        }
    }

    static void beginBrowserDraw(boolean transparent, BlendStateAccess stateAccess) {
        if (!transparent) {
            stateAccess.disableBlend();
            return;
        }
        stateAccess.enableBlend();
        stateAccess.blendFuncSeparate(GlStateManager.class_4535.ONE, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA, GlStateManager.class_4535.ONE, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
    }

    static void finishBrowserDraw(boolean transparent, BlendStateAccess stateAccess) {
        if (transparent) stateAccess.defaultBlendFunc();
        stateAccess.disableBlend();
    }

    /** Narrow seam for checking blend transitions without requiring a native OpenGL context. */
    interface BlendStateAccess {

        void enableBlend();

        void disableBlend();

        void blendFuncSeparate(GlStateManager.class_4535 sourceColor, GlStateManager.class_4534 destinationColor, GlStateManager.class_4535 sourceAlpha, GlStateManager.class_4534 destinationAlpha);

        void defaultBlendFunc();
    }

    private enum NativeBlendStateAccess implements BlendStateAccess {
        INSTANCE;

        @Override
        public void enableBlend() {
            RenderSystem.enableBlend();
        }

        @Override
        public void disableBlend() {
            RenderSystem.disableBlend();
        }

        @Override
        public void blendFuncSeparate(GlStateManager.class_4535 sourceColor, GlStateManager.class_4534 destinationColor, GlStateManager.class_4535 sourceAlpha, GlStateManager.class_4534 destinationAlpha) {
            RenderSystem.blendFuncSeparate(sourceColor, destinationColor, sourceAlpha, destinationAlpha);
        }

        @Override
        public void defaultBlendFunc() {
            RenderSystem.defaultBlendFunc();
        }
    }
}
