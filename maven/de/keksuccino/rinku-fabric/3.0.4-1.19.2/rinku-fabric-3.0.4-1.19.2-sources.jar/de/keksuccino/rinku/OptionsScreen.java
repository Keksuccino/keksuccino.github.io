package de.keksuccino.rinku;

import de.keksuccino.rinku.binarydownload.RinkuDownloader;
import org.cef.CefSettings;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_5244;

/** Rinku's loader-independent configuration screen implemented against Minecraft 1.19.2's immediate GUI API. */
public class OptionsScreen extends class_437 {

    private static final int BUTTON_HEIGHT = 20;
    private static final int BUTTON_ROW_MAX_WIDTH = 360;
    private static final int EDITABLE_LABEL_WIDTH = 155;
    private static final int EDITABLE_ROW_GAP = 5;
    private static final int OPTION_ROW_ADVANCE = 26;
    private static final int OPTIONS_TOP = 50;
    private static final int FOOTER_HEIGHT = 32;
    private static final int CYCLE_VALUE_COLOR = 0xFFAA00;
    private static final int INVALID_TEXT_COLOR = 0xFFFF5555;

    @Nullable
    private final class_437 parent;
    private final RinkuSettings settings;
    private final Map<String, String> pendingTextValues = new HashMap<>();
    private final EnumMap<Page, List<OptionControl>> controls = new EnumMap<>(Page.class);
    private final EnumMap<Page, Integer> scrollRows = new EnumMap<>(Page.class);
    private final List<TextOptionControl<?>> textOptionControls = new ArrayList<>();
    private final EnumMap<Page, class_4185> tabButtons = new EnumMap<>(Page.class);
    private Page selectedPage = Page.BROWSER;

    public OptionsScreen(@Nullable class_437 parent) {
        super(class_2561.method_43471("rinku.options"));
        this.parent = parent;
        this.settings = Rinku.getSettings();
        for (Page page : Page.values()) this.scrollRows.put(page, 0);
        this.initializePendingTextValues();
    }

    @Override
    protected void method_25426() {
        this.controls.clear();
        this.textOptionControls.clear();
        this.tabButtons.clear();
        for (Page page : Page.values()) this.controls.put(page, new ArrayList<>());
        this.buildTabs();
        this.buildBrowserOptions();
        this.buildDownloadOptions();
        this.buildAdvancedOptions();
        this.method_37063(new class_4185((this.field_22789 - 150) / 2, this.field_22790 - 27, 150, BUTTON_HEIGHT, class_5244.field_24334, ignored -> this.method_25419()));
        this.updateControlLayout();
    }

    private void initializePendingTextValues() {
        this.pendingTextValues.put("user-agent", this.settings.getUserAgent() == null ? "" : this.settings.getUserAgent());
        this.pendingTextValues.put("download-mirror", this.settings.getDownloadMirror() == null ? "" : this.settings.getDownloadMirror());
        this.pendingTextValues.put("download-connect-timeout-ms", Integer.toString(this.settings.getDownloadConnectTimeoutMs()));
        this.pendingTextValues.put("download-read-timeout-ms", Integer.toString(this.settings.getDownloadReadTimeoutMs()));
        this.pendingTextValues.put("download-max-archive-bytes", Long.toString(this.settings.getDownloadMaxArchiveBytes()));
        this.pendingTextValues.put("download-max-checksum-bytes", Long.toString(this.settings.getDownloadMaxChecksumBytes()));
        this.pendingTextValues.put("download-max-extracted-bytes", Long.toString(this.settings.getDownloadMaxExtractedBytes()));
    }

    private void buildTabs() {
        int totalWidth = this.getButtonWidth();
        int gap = 4;
        int tabWidth = (totalWidth - gap * (Page.values().length - 1)) / Page.values().length;
        int x = (this.field_22789 - totalWidth) / 2;
        for (Page page : Page.values()) {
            class_4185 button = this.method_37063(new class_4185(x, 24, tabWidth, BUTTON_HEIGHT, class_2561.method_43471(page.translationKey), ignored -> this.selectPage(page)));
            this.tabButtons.put(page, button);
            x += tabWidth + gap;
        }
    }

    private void buildBrowserOptions() {
        this.addTextOption(Page.BROWSER, new TextOption<>("user-agent", "rinku.options.user_agent", "rinku.options.user_agent.desc", 512, RinkuOptionsInput::parseUserAgent, this.settings::getUserAgent, this.settings::setUserAgent, class_2561.method_43471("rinku.options.validation.user_agent")));
        this.addButtonOption(Page.BROWSER, this.buildBooleanButton("rinku.options.use_cache", "rinku.options.use_cache.desc", this.settings::isUsingCache, this.settings::setUseCache), () -> true);
        this.addButtonOption(Page.BROWSER, this.buildBooleanButton("rinku.options.enable_widevine", "rinku.options.enable_widevine.desc", this.settings::isEnableWidevineCdm, this.settings::setEnableWidevineCdm), () -> true);
        class_4185 preloadButton = this.optionButton(this.booleanOptionMessage("rinku.options.preload_enabled", this.settings.isBrowserPreloadEnabled()), "rinku.options.preload_enabled.desc", button -> {
            this.settings.setBrowserPreloadEnabled(!this.settings.isBrowserPreloadEnabled());
            button.method_25355(this.booleanOptionMessage("rinku.options.preload_enabled", this.settings.isBrowserPreloadEnabled()));
            this.updateControlLayout();
        });
        this.addButtonOption(Page.BROWSER, preloadButton, () -> true);
        this.addButtonOption(Page.BROWSER, this.buildPoolSizeButton("rinku.options.preload_transparent_pool_size", "rinku.options.preload_transparent_pool_size.desc", this.settings::getBrowserPreloadTransparentPoolSize, this.settings::setBrowserPreloadTransparentPoolSize), this.settings::isBrowserPreloadEnabled);
        this.addButtonOption(Page.BROWSER, this.buildPoolSizeButton("rinku.options.preload_opaque_pool_size", "rinku.options.preload_opaque_pool_size.desc", this.settings::getBrowserPreloadOpaquePoolSize, this.settings::setBrowserPreloadOpaquePoolSize), this.settings::isBrowserPreloadEnabled);
    }

    private void buildDownloadOptions() {
        this.addButtonOption(Page.DOWNLOADS, this.buildBooleanButton("rinku.options.skip_download", "rinku.options.skip_download.desc", this.settings::isSkipDownload, this.settings::setSkipDownload), () -> true);
        class_4185 mirrorPolicyButton = this.optionButton(this.mirrorPolicyMessage(), "rinku.options.download_mirror_policy.desc", button -> {
            this.settings.setDownloadMirrorPolicy(nextValue(this.settings.getDownloadMirrorPolicy(), RinkuDownloader.MirrorPolicy.values()));
            button.method_25355(this.mirrorPolicyMessage());
            this.validateTextOptions();
        });
        this.addButtonOption(Page.DOWNLOADS, mirrorPolicyButton, () -> true);
        this.addTextOption(Page.DOWNLOADS, new TextOption<>("download-mirror", "rinku.options.download_mirror", "rinku.options.download_mirror.desc", 2048, this::parseDownloadMirror, this.settings::getDownloadMirror, this.settings::setDownloadMirror, class_2561.method_43471("rinku.options.validation.download_mirror")));
        this.addButtonOption(Page.DOWNLOADS, this.buildBooleanButton("rinku.options.enforce_checksums", "rinku.options.enforce_checksums.desc", this.settings::isEnforceDownloadChecksums, this.settings::setEnforceDownloadChecksums), () -> true);
        this.addTextOption(Page.DOWNLOADS, new TextOption<>("download-connect-timeout-ms", "rinku.options.connect_timeout", "rinku.options.connect_timeout.desc", 6, value -> RinkuOptionsInput.parseInt(value, RinkuSettings.MIN_DOWNLOAD_TIMEOUT_MS, RinkuSettings.MAX_DOWNLOAD_TIMEOUT_MS), this.settings::getDownloadConnectTimeoutMs, this.settings::setDownloadConnectTimeoutMs, class_2561.method_43469("rinku.options.validation.integer_range", RinkuSettings.MIN_DOWNLOAD_TIMEOUT_MS, RinkuSettings.MAX_DOWNLOAD_TIMEOUT_MS)));
        this.addTextOption(Page.DOWNLOADS, new TextOption<>("download-read-timeout-ms", "rinku.options.read_timeout", "rinku.options.read_timeout.desc", 6, value -> RinkuOptionsInput.parseInt(value, RinkuSettings.MIN_DOWNLOAD_TIMEOUT_MS, RinkuSettings.MAX_DOWNLOAD_TIMEOUT_MS), this.settings::getDownloadReadTimeoutMs, this.settings::setDownloadReadTimeoutMs, class_2561.method_43469("rinku.options.validation.integer_range", RinkuSettings.MIN_DOWNLOAD_TIMEOUT_MS, RinkuSettings.MAX_DOWNLOAD_TIMEOUT_MS)));
        this.addTextOption(Page.DOWNLOADS, new TextOption<>("download-max-archive-bytes", "rinku.options.max_archive_bytes", "rinku.options.max_archive_bytes.desc", 10, value -> RinkuOptionsInput.parseLong(value, RinkuSettings.MIN_DOWNLOAD_ARCHIVE_BYTES, RinkuSettings.MAX_DOWNLOAD_ARCHIVE_BYTES), this.settings::getDownloadMaxArchiveBytes, this.settings::setDownloadMaxArchiveBytes, class_2561.method_43469("rinku.options.validation.integer_range", RinkuSettings.MIN_DOWNLOAD_ARCHIVE_BYTES, RinkuSettings.MAX_DOWNLOAD_ARCHIVE_BYTES)));
        this.addTextOption(Page.DOWNLOADS, new TextOption<>("download-max-checksum-bytes", "rinku.options.max_checksum_bytes", "rinku.options.max_checksum_bytes.desc", 7, value -> RinkuOptionsInput.parseLong(value, RinkuSettings.MIN_DOWNLOAD_CHECKSUM_BYTES, RinkuSettings.MAX_DOWNLOAD_CHECKSUM_BYTES), this.settings::getDownloadMaxChecksumBytes, this.settings::setDownloadMaxChecksumBytes, class_2561.method_43469("rinku.options.validation.integer_range", RinkuSettings.MIN_DOWNLOAD_CHECKSUM_BYTES, RinkuSettings.MAX_DOWNLOAD_CHECKSUM_BYTES)));
        this.addTextOption(Page.DOWNLOADS, new TextOption<>("download-max-extracted-bytes", "rinku.options.max_extracted_bytes", "rinku.options.max_extracted_bytes.desc", 11, value -> RinkuOptionsInput.parseLong(value, RinkuSettings.MIN_DOWNLOAD_EXTRACTED_BYTES, RinkuSettings.MAX_DOWNLOAD_EXTRACTED_BYTES), this.settings::getDownloadMaxExtractedBytes, this.settings::setDownloadMaxExtractedBytes, class_2561.method_43469("rinku.options.validation.integer_range", RinkuSettings.MIN_DOWNLOAD_EXTRACTED_BYTES, RinkuSettings.MAX_DOWNLOAD_EXTRACTED_BYTES)));
    }

    private void buildAdvancedOptions() {
        this.addButtonOption(Page.ADVANCED, this.buildBooleanButton("rinku.options.disable_web_security", "rinku.options.disable_web_security.desc", this.settings::isDisableWebSecurity, this.settings::setDisableWebSecurity), () -> true);
        this.addButtonOption(Page.ADVANCED, this.buildLogSeverityButton("rinku.options.native_log_severity", "rinku.options.native_log_severity.desc", this.settings::getNativeCefLogSeverity, this.settings::setNativeCefLogSeverity), () -> true);
        this.addButtonOption(Page.ADVANCED, this.buildLogSeverityButton("rinku.options.console_log_severity", "rinku.options.console_log_severity.desc", this.settings::getConsoleLogForwardingMinSeverity, this.settings::setConsoleLogForwardingMinSeverity), () -> true);
    }

    private class_4185 buildBooleanButton(String labelKey, String descriptionKey, Supplier<Boolean> getter, Consumer<Boolean> setter) {
        return this.optionButton(this.booleanOptionMessage(labelKey, getter.get()), descriptionKey, button -> {
            boolean next = !getter.get();
            setter.accept(next);
            button.method_25355(this.booleanOptionMessage(labelKey, next));
        });
    }

    private class_4185 buildPoolSizeButton(String labelKey, String descriptionKey, Supplier<Integer> getter, Consumer<Integer> setter) {
        return this.optionButton(this.integerOptionMessage(labelKey, getter.get()), descriptionKey, button -> {
            int next = getter.get() >= RinkuSettings.MAX_BROWSER_PRELOAD_POOL_SIZE ? RinkuSettings.MIN_BROWSER_PRELOAD_POOL_SIZE : getter.get() + 1;
            setter.accept(next);
            button.method_25355(this.integerOptionMessage(labelKey, next));
        });
    }

    private class_4185 buildLogSeverityButton(String labelKey, String descriptionKey, Supplier<CefSettings.LogSeverity> getter, Consumer<CefSettings.LogSeverity> setter) {
        return this.optionButton(this.logSeverityMessage(labelKey, getter.get()), descriptionKey, button -> {
            CefSettings.LogSeverity next = nextValue(getter.get(), CefSettings.LogSeverity.values());
            setter.accept(next);
            button.method_25355(this.logSeverityMessage(labelKey, next));
        });
    }

    private class_4185 optionButton(class_2561 message, String descriptionKey, class_4185.class_4241 onPress) {
        class_2561 description = class_2561.method_43471(descriptionKey);
        return new class_4185(0, 0, this.getButtonWidth(), BUTTON_HEIGHT, message, onPress, (button, poseStack, mouseX, mouseY) -> this.method_25424(poseStack, description, mouseX, mouseY));
    }

    private void addButtonOption(Page page, class_4185 button, Supplier<Boolean> enabled) {
        this.method_37063(button);
        List<OptionControl> pageControls = this.controls.get(page);
        pageControls.add(new ButtonOptionControl(page, pageControls.size(), button, enabled));
    }

    private <T> void addTextOption(Page page, TextOption<T> option) {
        class_2561 label = class_2561.method_43471(option.labelKey());
        class_342 editBox = this.method_37063(new class_342(this.field_22793, 0, 0, 100, BUTTON_HEIGHT, label));
        String initialValue = this.pendingTextValues.getOrDefault(option.id(), "");
        editBox.method_1880(Math.max(option.maxLength(), initialValue.length()));
        List<OptionControl> pageControls = this.controls.get(page);
        TextOptionControl<T> control = new TextOptionControl<>(page, pageControls.size(), option, label, editBox, class_2561.method_43471(option.descriptionKey()));
        editBox.method_1863(value -> {
            this.pendingTextValues.put(option.id(), value);
            control.validate();
        });
        editBox.method_1852(initialValue);
        control.validate();
        pageControls.add(control);
        this.textOptionControls.add(control);
    }

    private String parseDownloadMirror(String value) {
        return RinkuOptionsInput.parseMirror(value, this.settings.getDownloadMirrorPolicy() != RinkuDownloader.MirrorPolicy.CONFIGURED_ONLY);
    }

    private void selectPage(Page page) {
        if (this.selectedPage == page) return;
        this.selectedPage = page;
        this.method_25395(null);
        for (TextOptionControl<?> control : this.textOptionControls) control.editBox.method_1876(false);
        this.updateControlLayout();
    }

    private void updateControlLayout() {
        int rowWidth = this.getButtonWidth();
        int rowX = (this.field_22789 - rowWidth) / 2;
        int footerTop = this.field_22790 - FOOTER_HEIGHT;
        int visibleRows = this.getVisibleRowCount();
        for (Page page : Page.values()) {
            List<OptionControl> pageControls = this.controls.get(page);
            int maxScroll = Math.max(0, pageControls.size() - visibleRows);
            int scroll = class_3532.method_15340(this.scrollRows.getOrDefault(page, 0), 0, maxScroll);
            this.scrollRows.put(page, scroll);
            for (OptionControl control : pageControls) {
                int y = OPTIONS_TOP + (control.rowIndex - scroll) * OPTION_ROW_ADVANCE;
                boolean visible = page == this.selectedPage && y >= OPTIONS_TOP && y + BUTTON_HEIGHT <= footerTop;
                control.layout(rowX, y, rowWidth, visible);
            }
            class_4185 tabButton = this.tabButtons.get(page);
            if (tabButton != null) tabButton.field_22763 = page != this.selectedPage;
        }
    }

    private int getVisibleRowCount() {
        return Math.max(1, (this.field_22790 - FOOTER_HEIGHT - OPTIONS_TOP) / OPTION_ROW_ADVANCE);
    }

    private int getButtonWidth() {
        return Math.max(120, Math.min(BUTTON_ROW_MAX_WIDTH, this.field_22789 - 40));
    }

    private void validateTextOptions() {
        for (TextOptionControl<?> control : this.textOptionControls) control.validate();
    }

    private boolean applyTextOptions() {
        TextOptionControl<?> firstInvalid = null;
        for (TextOptionControl<?> control : this.textOptionControls) {
            if (!control.validate() && firstInvalid == null) firstInvalid = control;
        }
        if (firstInvalid != null) {
            this.selectedPage = firstInvalid.page();
            int centeredRow = Math.max(0, firstInvalid.rowIndex() - this.getVisibleRowCount() / 2);
            this.scrollRows.put(firstInvalid.page(), centeredRow);
            this.updateControlLayout();
            this.method_25395(firstInvalid.editBox);
            firstInvalid.editBox.method_1876(true);
            return false;
        }
        for (TextOptionControl<?> control : this.textOptionControls) control.applyParsedValue();
        return true;
    }

    private class_2561 booleanOptionMessage(String labelKey, boolean enabled) {
        class_2561 value = class_2561.method_43471(enabled ? "rinku.options.toggle.enabled" : "rinku.options.toggle.disabled").method_27696(class_2583.field_24360.method_10977(enabled ? class_124.field_1060 : class_124.field_1061));
        return class_2561.method_43469(labelKey, value);
    }

    private class_2561 integerOptionMessage(String labelKey, int value) {
        return class_2561.method_43469(labelKey, this.cycleValue(class_2561.method_43470(Integer.toString(value))));
    }

    private class_2561 mirrorPolicyMessage() {
        String valueKey = "rinku.options.download_mirror_policy." + this.settings.getDownloadMirrorPolicy().name().toLowerCase(java.util.Locale.ROOT);
        return class_2561.method_43469("rinku.options.download_mirror_policy", this.cycleValue(class_2561.method_43471(valueKey)));
    }

    private class_2561 logSeverityMessage(String labelKey, CefSettings.LogSeverity severity) {
        String severityName = severity.name().substring("LOGSEVERITY_".length()).toLowerCase(java.util.Locale.ROOT);
        return class_2561.method_43469(labelKey, this.cycleValue(class_2561.method_43471("rinku.options.log_severity." + severityName)));
    }

    private class_2561 cycleValue(class_2561 value) {
        return value.method_27661().method_27696(class_2583.field_24360.method_36139(CYCLE_VALUE_COLOR));
    }

    private static <T> T nextValue(T current, T[] values) {
        for (int index = 0; index < values.length; index++) {
            if (values[index] == current) return values[(index + 1) % values.length];
        }
        return values[0];
    }

    @Override
    public void method_25394(class_4587 poseStack, int mouseX, int mouseY, float partialTick) {
        this.method_25420(poseStack);
        method_27534(poseStack, this.field_22793, this.field_22785, this.field_22789 / 2, 8, 0xFFFFFF);
        super.method_25394(poseStack, mouseX, mouseY, partialTick);
        for (OptionControl control : this.controls.get(this.selectedPage)) control.renderSupplement(poseStack, mouseX, mouseY);
        this.renderScrollbar(poseStack);
    }

    private void renderScrollbar(class_4587 poseStack) {
        List<OptionControl> pageControls = this.controls.get(this.selectedPage);
        int visibleRows = this.getVisibleRowCount();
        if (pageControls.size() <= visibleRows) return;
        int x = (this.field_22789 + this.getButtonWidth()) / 2 + 5;
        int top = OPTIONS_TOP;
        int bottom = this.field_22790 - FOOTER_HEIGHT;
        int trackHeight = bottom - top;
        int thumbHeight = Math.max(12, trackHeight * visibleRows / pageControls.size());
        int maxScroll = pageControls.size() - visibleRows;
        int thumbY = top + (trackHeight - thumbHeight) * this.scrollRows.get(this.selectedPage) / maxScroll;
        method_25294(poseStack, x, top, x + 2, bottom, 0x66000000);
        method_25294(poseStack, x, thumbY, x + 2, thumbY + thumbHeight, 0xFFAAAAAA);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollDelta) {
        List<OptionControl> pageControls = this.controls.get(this.selectedPage);
        int maxScroll = Math.max(0, pageControls.size() - this.getVisibleRowCount());
        if (maxScroll > 0 && mouseY >= OPTIONS_TOP && mouseY < this.field_22790 - FOOTER_HEIGHT && scrollDelta != 0.0D) {
            int direction = scrollDelta > 0.0D ? -1 : 1;
            this.scrollRows.put(this.selectedPage, class_3532.method_15340(this.scrollRows.get(this.selectedPage) + direction, 0, maxScroll));
            this.updateControlLayout();
            return true;
        }
        return super.method_25401(mouseX, mouseY, scrollDelta);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_TAB && method_25441()) {
            Page[] pages = Page.values();
            this.selectPage(pages[(this.selectedPage.ordinal() + (method_25442() ? pages.length - 1 : 1)) % pages.length]);
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public void method_25419() {
        if (!this.applyTextOptions()) return;
        class_310.method_1551().method_1507(this.parent);
    }

    private enum Page {
        BROWSER("rinku.options.tab.browser"),
        DOWNLOADS("rinku.options.tab.downloads"),
        ADVANCED("rinku.options.tab.advanced");

        private final String translationKey;

        Page(String translationKey) {
            this.translationKey = translationKey;
        }
    }

    private record TextOption<T>(String id, String labelKey, String descriptionKey, int maxLength, Function<String, T> parser, Supplier<T> currentValue, Consumer<T> applier, class_2561 invalidMessage) {
    }

    private abstract class OptionControl {

        private final Page page;
        private final int rowIndex;

        private OptionControl(Page page, int rowIndex) {
            this.page = page;
            this.rowIndex = rowIndex;
        }

        final Page page() {
            return this.page;
        }

        final int rowIndex() {
            return this.rowIndex;
        }

        abstract void layout(int x, int y, int width, boolean visible);

        void renderSupplement(class_4587 poseStack, int mouseX, int mouseY) {
        }
    }

    private final class ButtonOptionControl extends OptionControl {

        private final class_4185 button;
        private final Supplier<Boolean> enabled;

        private ButtonOptionControl(Page page, int rowIndex, class_4185 button, Supplier<Boolean> enabled) {
            super(page, rowIndex);
            this.button = button;
            this.enabled = enabled;
        }

        @Override
        void layout(int x, int y, int width, boolean visible) {
            this.button.field_22760 = x;
            this.button.field_22761 = y;
            this.button.method_25358(width);
            this.button.field_22764 = visible;
            this.button.field_22763 = visible && this.enabled.get();
        }
    }

    private final class TextOptionControl<T> extends OptionControl {

        private final TextOption<T> option;
        private final class_2561 label;
        private final class_342 editBox;
        private final class_2561 description;
        @Nullable
        private T parsedValue;
        private int labelX;
        private int rowY;
        private int labelWidth;

        private TextOptionControl(Page page, int rowIndex, TextOption<T> option, class_2561 label, class_342 editBox, class_2561 description) {
            super(page, rowIndex);
            this.option = option;
            this.label = label;
            this.editBox = editBox;
            this.description = description;
        }

        private boolean validate() {
            try {
                this.parsedValue = this.option.parser().apply(this.editBox.method_1882());
                this.editBox.method_1868(class_342.field_32196);
                return true;
            } catch (IllegalArgumentException ignored) {
                this.parsedValue = null;
                this.editBox.method_1868(INVALID_TEXT_COLOR);
                return false;
            }
        }

        private void applyParsedValue() {
            if (!Objects.equals(this.parsedValue, this.option.currentValue().get())) this.option.applier().accept(this.parsedValue);
        }

        @Override
        void layout(int x, int y, int width, boolean visible) {
            this.labelWidth = Math.min(EDITABLE_LABEL_WIDTH, Math.max(80, width / 2));
            this.labelX = x;
            this.rowY = y;
            this.editBox.field_22760 = x + this.labelWidth + EDITABLE_ROW_GAP;
            this.editBox.field_22761 = y;
            this.editBox.method_25358(Math.max(40, width - this.labelWidth - EDITABLE_ROW_GAP));
            this.editBox.field_22764 = visible;
            this.editBox.field_22763 = visible;
            if (!visible) this.editBox.method_1876(false);
        }

        @Override
        void renderSupplement(class_4587 poseStack, int mouseX, int mouseY) {
            if (!this.editBox.field_22764) return;
            method_27535(poseStack, OptionsScreen.this.field_22793, this.label, this.labelX, this.rowY + 6, 0xFFFFFF);
            boolean labelHovered = mouseX >= this.labelX && mouseX < this.labelX + this.labelWidth && mouseY >= this.rowY && mouseY < this.rowY + BUTTON_HEIGHT;
            if (labelHovered || this.editBox.method_25405(mouseX, mouseY)) {
                class_2561 tooltip = this.parsedValue == null ? this.option.invalidMessage() : this.description;
                OptionsScreen.this.method_25424(poseStack, tooltip, mouseX, mouseY);
            }
        }
    }

}
