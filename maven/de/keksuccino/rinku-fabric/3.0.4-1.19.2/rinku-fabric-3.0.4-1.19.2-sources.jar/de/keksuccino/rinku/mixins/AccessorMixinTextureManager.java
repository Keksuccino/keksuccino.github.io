package de.keksuccino.rinku.mixins;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;
import net.minecraft.class_1044;
import net.minecraft.class_1060;
import net.minecraft.class_2960;

@Mixin(class_1060.class)
public interface AccessorMixinTextureManager {

    @Accessor("byPath")
    Map<class_2960, class_1044> getByPath_Rinku();

}
