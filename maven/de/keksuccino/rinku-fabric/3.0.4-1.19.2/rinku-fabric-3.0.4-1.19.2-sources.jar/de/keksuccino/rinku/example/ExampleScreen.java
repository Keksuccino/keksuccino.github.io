package de.keksuccino.rinku.example;

import de.keksuccino.rinku.Rinku;
import de.keksuccino.rinku.RinkuBrowser;
import de.keksuccino.rinku.RinkuBrowserTextureBlitter;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import org.cef.browser.CefBrowser;
import org.cef.browser.CefFrame;
import org.cef.handler.CefDisplayHandler;
import org.cef.handler.CefDisplayHandlerAdapter;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.glfw.GLFW;

public class ExampleScreen extends class_437 {

    private static final int FRAME_MARGIN = 20;
    private static final int NAV_BAR_HEIGHT = 20;
    private static final int NAV_BAR_GAP = 6;
    private static final int NAV_BUTTON_WIDTH = 24;
    private static final int NAV_SPACING = 4;
    private static final int LOADING_BAR_HEIGHT = 2;
    private static final int LOADING_BAR_TRACK_COLOR = 0x55000000;
    private static final int LOADING_BAR_FILL_COLOR = 0xFF3BA8FF;
    private static final String DEFAULT_URL = "https://www.google.com";

    private RinkuBrowser browser;
    private class_342 urlBox;
    private class_4185 backButton;
    private class_4185 forwardButton;
    private class_4185 reloadButton;
    private CefDisplayHandler addressBarDisplayHandler;

    public ExampleScreen(class_2561 component) {
        super(component);
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        if (this.browser == null) this.browser = Rinku.createBrowser(DEFAULT_URL, true);
        this.registerAddressBarDisplayHandler();
        this.initNavigationWidgets();
        this.resizeBrowser();
        this.refreshNavigationState();
    }

    private void registerAddressBarDisplayHandler() {
        if (this.addressBarDisplayHandler != null) return;
        this.addressBarDisplayHandler = new CefDisplayHandlerAdapter() {
            @Override
            public void onAddressChange(CefBrowser cefBrowser, CefFrame frame, String url) {
                if (ExampleScreen.this.browser == null || cefBrowser == null || frame == null || !frame.isMain()) return;
                if (cefBrowser.getIdentifier() != ExampleScreen.this.browser.getIdentifier()) return;
                ExampleScreen.this.field_22787.execute(() -> {
                    if (ExampleScreen.this.field_22787.field_1755 != ExampleScreen.this || ExampleScreen.this.urlBox == null || url == null || url.isBlank()) return;
                    if (!url.equals(ExampleScreen.this.urlBox.method_1882())) ExampleScreen.this.urlBox.method_1852(url);
                });
            }
        };
        Rinku.getClient().addDisplayHandler(this.addressBarDisplayHandler);
    }

    private void initNavigationWidgets() {
        int navX = FRAME_MARGIN;
        int navY = FRAME_MARGIN;
        this.backButton = this.method_37063(new class_4185(navX, navY, NAV_BUTTON_WIDTH, NAV_BAR_HEIGHT, class_2561.method_43470("<"), button -> this.browser.goBack()));
        navX += NAV_BUTTON_WIDTH + NAV_SPACING;
        this.forwardButton = this.method_37063(new class_4185(navX, navY, NAV_BUTTON_WIDTH, NAV_BAR_HEIGHT, class_2561.method_43470(">"), button -> this.browser.goForward()));
        navX += NAV_BUTTON_WIDTH + NAV_SPACING;
        this.reloadButton = this.method_37063(new class_4185(navX, navY, NAV_BUTTON_WIDTH, NAV_BAR_HEIGHT, class_2561.method_43470("R"), button -> this.browser.reload()));
        navX += NAV_BUTTON_WIDTH + NAV_SPACING;

        int urlWidth = Math.max(60, this.field_22789 - FRAME_MARGIN - navX);
        this.urlBox = this.method_37063(new class_342(this.field_22793, navX, navY, urlWidth, NAV_BAR_HEIGHT, class_2561.method_43470("URL")));
        this.urlBox.method_1880(2048);
        String currentUrl = this.browser.getURL();
        this.urlBox.method_1852(currentUrl == null || currentUrl.isBlank() ? DEFAULT_URL : currentUrl);
    }

    private int getBrowserX() {
        return FRAME_MARGIN;
    }

    private int getBrowserY() {
        return FRAME_MARGIN + NAV_BAR_HEIGHT + NAV_BAR_GAP;
    }

    private int getBrowserWidth() {
        return Math.max(1, this.field_22789 - FRAME_MARGIN * 2);
    }

    private int getBrowserHeight() {
        return Math.max(1, this.field_22790 - this.getBrowserY() - FRAME_MARGIN);
    }

    private boolean isInBrowserBounds(double x, double y) {
        return x >= this.getBrowserX() && y >= this.getBrowserY() && x < this.getBrowserX() + this.getBrowserWidth() && y < this.getBrowserY() + this.getBrowserHeight();
    }

    private int browserMouseX(double x) {
        return (int) ((x - this.getBrowserX()) * this.field_22787.method_22683().method_4495());
    }

    private int browserMouseY(double y) {
        return (int) ((y - this.getBrowserY()) * this.field_22787.method_22683().method_4495());
    }

    private void resizeBrowser() {
        if (this.browser == null) return;
        this.browser.resize((int) (this.getBrowserWidth() * this.field_22787.method_22683().method_4495()), (int) (this.getBrowserHeight() * this.field_22787.method_22683().method_4495()));
    }

    @Override
    public void method_25410(@NotNull class_310 minecraft, int width, int height) {
        super.method_25410(minecraft, width, height);
        this.resizeBrowser();
    }

    @Override
    public void method_25419() {
        if (this.addressBarDisplayHandler != null && Rinku.isInitialized()) Rinku.getClient().removeDisplayHandler(this.addressBarDisplayHandler);
        this.addressBarDisplayHandler = null;
        if (this.browser != null) this.browser.close();
        super.method_25419();
    }

    @Override
    public void method_25393() {
        super.method_25393();
        if (this.urlBox != null) this.urlBox.method_1865();
        this.refreshNavigationState();
    }

    private void refreshNavigationState() {
        if (this.browser == null) return;
        if (this.backButton != null) this.backButton.field_22763 = this.browser.canGoBack();
        if (this.forwardButton != null) this.forwardButton.field_22763 = this.browser.canGoForward();
        if (this.reloadButton != null) this.reloadButton.field_22763 = true;
        if (this.urlBox != null && !this.urlBox.method_25370()) {
            String currentUrl = this.browser.getURL();
            if (currentUrl != null && !currentUrl.isBlank() && !currentUrl.equals(this.urlBox.method_1882())) this.urlBox.method_1852(currentUrl);
        }
    }

    private void navigateFromUrlField() {
        if (this.urlBox == null || this.browser == null) return;
        String input = this.urlBox.method_1882();
        if (input == null || input.trim().isEmpty()) return;
        String normalizedUrl = this.normalizeUrl(input.trim());
        this.urlBox.method_1852(normalizedUrl);
        this.browser.loadURL(normalizedUrl);
        this.clearNavigationFocus();
        this.browser.setFocus(true);
    }

    private void clearNavigationFocus() {
        this.method_25395(null);
        if (this.backButton != null && this.backButton.method_25370()) this.backButton.method_25407(false);
        if (this.forwardButton != null && this.forwardButton.method_25370()) this.forwardButton.method_25407(false);
        if (this.reloadButton != null && this.reloadButton.method_25370()) this.reloadButton.method_25407(false);
        if (this.urlBox != null) this.urlBox.method_1876(false);
    }

    private String normalizeUrl(String input) {
        if (input.matches("^[a-zA-Z][a-zA-Z0-9+.-]*:.*")) return input;
        return "https://" + input;
    }

    @Override
    public void method_25394(@NotNull class_4587 poseStack, int mouseX, int mouseY, float partialTick) {
        this.method_25420(poseStack);
        if (this.browser != null && this.browser.isTextureReady()) this.renderBrowserTexture(poseStack);
        super.method_25394(poseStack, mouseX, mouseY, partialTick);
        this.renderLoadingIndicator(poseStack);
    }

    private void renderBrowserTexture(class_4587 poseStack) {
        RinkuBrowserTextureBlitter.blit(poseStack, this.browser, this.getBrowserX(), this.getBrowserY(), this.getBrowserWidth(), this.getBrowserHeight());
    }

    private void renderLoadingIndicator(class_4587 poseStack) {
        if (this.browser == null || this.urlBox == null || !this.browser.isLoading()) return;
        int barX = this.urlBox.field_22760;
        int barY = this.urlBox.field_22761 + 1;
        int barWidth = this.urlBox.method_25368();
        int barBottom = barY + LOADING_BAR_HEIGHT;
        method_25294(poseStack, barX, barY, barX + barWidth, barBottom, LOADING_BAR_TRACK_COLOR);
        int segmentWidth = Math.max(20, barWidth / 4);
        int travelRange = barWidth + segmentWidth;
        int animatedOffset = (int) ((class_156.method_658() / 6L) % travelRange) - segmentWidth;
        int segmentStart = Math.max(barX, barX + animatedOffset);
        int segmentEnd = Math.min(barX + barWidth, barX + animatedOffset + segmentWidth);
        if (segmentEnd > segmentStart) method_25294(poseStack, segmentStart, barY, segmentEnd, barBottom, LOADING_BAR_FILL_COLOR);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (super.method_25402(mouseX, mouseY, button)) return true;
        if (!this.isInBrowserBounds(mouseX, mouseY)) return false;
        this.clearNavigationFocus();
        this.browser.sendMousePress(this.browserMouseX(mouseX), this.browserMouseY(mouseY), button);
        this.browser.setFocus(true);
        return true;
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        if (super.method_25406(mouseX, mouseY, button)) return true;
        this.browser.sendMouseRelease(this.browserMouseX(mouseX), this.browserMouseY(mouseY), button);
        this.browser.setFocus(true);
        return true;
    }

    @Override
    public void method_16014(double mouseX, double mouseY) {
        if (this.isInBrowserBounds(mouseX, mouseY)) this.browser.sendMouseMove(this.browserMouseX(mouseX), this.browserMouseY(mouseY));
        super.method_16014(mouseX, mouseY);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
        return super.method_25403(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollY) {
        if (super.method_25401(mouseX, mouseY, scrollY)) return true;
        if (!this.isInBrowserBounds(mouseX, mouseY)) return false;
        this.browser.sendMouseWheel(this.browserMouseX(mouseX), this.browserMouseY(mouseY), scrollY, 0);
        return true;
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (this.urlBox != null && this.urlBox.method_25370() && (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER)) {
            this.navigateFromUrlField();
            return true;
        }
        if (super.method_25404(keyCode, scanCode, modifiers)) return true;
        if (this.urlBox != null && this.urlBox.method_25370()) return true;
        this.browser.sendKeyPress(keyCode, scanCode, modifiers);
        this.browser.setFocus(true);
        return true;
    }

    @Override
    public boolean method_16803(int keyCode, int scanCode, int modifiers) {
        if (super.method_16803(keyCode, scanCode, modifiers)) return true;
        if (this.urlBox != null && this.urlBox.method_25370()) return true;
        this.browser.sendKeyRelease(keyCode, scanCode, modifiers);
        this.browser.setFocus(true);
        return true;
    }

    @Override
    public boolean method_25400(char codePoint, int modifiers) {
        if (super.method_25400(codePoint, modifiers)) return true;
        if (this.urlBox != null && this.urlBox.method_25370()) return true;
        if (codePoint == 0) return false;
        this.browser.sendKeyTyped(codePoint, modifiers);
        this.browser.setFocus(true);
        return true;
    }

}
