package de.keksuccino.rinku;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.nio.ByteBuffer;
import java.util.UUID;
import net.minecraft.class_1044;
import net.minecraft.class_2960;
import net.minecraft.class_310;

import static org.lwjgl.opengl.GL12.GL_BGRA;
import static org.lwjgl.opengl.GL12.GL_TEXTURE_2D;
import static org.lwjgl.opengl.GL12.GL_UNPACK_ROW_LENGTH;
import static org.lwjgl.opengl.GL12.GL_UNPACK_SKIP_PIXELS;
import static org.lwjgl.opengl.GL12.GL_UNPACK_SKIP_ROWS;
import static org.lwjgl.opengl.GL12.GL_UNSIGNED_INT_8_8_8_8_REV;
import static org.lwjgl.opengl.GL12.glTexSubImage2D;

/** Uploads CEF's BGRA paint buffers into a texture owned by Minecraft's texture manager. */
public class RinkuRenderer {

    private final boolean transparent;
    private final class_2960 textureIdentifier;
    private RinkuDirectTexture texture;
    private int textureWidth;
    private int textureHeight;
    private boolean textureRegistered;
    private boolean textureUploaded;

    protected RinkuRenderer(boolean transparent) {
        this.transparent = transparent;
        String uniqueId = UUID.randomUUID().toString().toLowerCase().replace("-", "");
        this.textureIdentifier = class_2960.method_60655(Rinku.MOD_ID, "browser_" + uniqueId);
    }

    public void initialize() {
        RenderSystem.assertOnRenderThread();
        if (this.textureRegistered) return;
        this.texture = new RinkuDirectTexture();
        class_310.method_1551().method_1531().method_4616(this.textureIdentifier, this.texture);
        this.textureRegistered = true;
    }

    public class_1044 getTexture() {
        return this.texture;
    }

    /** Resource identifier suitable for {@link net.minecraft.class_332} texture methods. */
    public class_2960 getTextureIdentifier() {
        return this.textureIdentifier;
    }

    public boolean isTextureReady() {
        return this.textureRegistered && this.textureUploaded && this.texture != null && this.texture.isTextureViewReady();
    }

    public int getTextureID() {
        if (!this.isTextureReady() || !RenderSystem.isOnRenderThreadOrInit()) return 0;
        return this.texture.method_4624();
    }

    public boolean supportsDirtyRectUpload() {
        return this.isTextureReady();
    }

    public int getTextureWidth() {
        return this.textureWidth;
    }

    public int getTextureHeight() {
        return this.textureHeight;
    }

    public boolean isTransparent() {
        return this.transparent;
    }

    protected void cleanup() {
        RenderSystem.assertOnRenderThread();
        this.textureUploaded = false;
        this.textureWidth = 0;
        this.textureHeight = 0;
        if (this.textureRegistered) {
            class_310.method_1551().method_1531().method_4615(this.textureIdentifier);
            this.textureRegistered = false;
        }
        this.texture = null;
    }

    protected void onPaint(ByteBuffer buffer, int width, int height) {
        RenderSystem.assertOnRenderThread();
        if (!isValidUpload(buffer, width, height) || this.texture == null) return;

        this.texture.ensureStorage(width, height);
        this.textureWidth = width;
        this.textureHeight = height;
        GlStateManager._bindTexture(this.texture.method_4624());
        GlStateManager._pixelStore(GL_UNPACK_ROW_LENGTH, width);
        GlStateManager._pixelStore(GL_UNPACK_SKIP_PIXELS, 0);
        GlStateManager._pixelStore(GL_UNPACK_SKIP_ROWS, 0);
        glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, width, height, GL_BGRA, GL_UNSIGNED_INT_8_8_8_8_REV, buffer);
        this.textureUploaded = true;
    }

    protected void onPaint(ByteBuffer buffer, int x, int y, int width, int height) {
        RenderSystem.assertOnRenderThread();
        if (!isValidUpload(buffer, width, height) || !this.isTextureReady()) return;
        GlStateManager._bindTexture(this.texture.method_4624());
        glTexSubImage2D(GL_TEXTURE_2D, 0, x, y, width, height, GL_BGRA, GL_UNSIGNED_INT_8_8_8_8_REV, buffer);
    }

    private static boolean isValidUpload(ByteBuffer buffer, int width, int height) {
        if (buffer == null || width <= 0 || height <= 0) return false;
        long requiredBytes = (long) width * height * 4L;
        return requiredBytes <= buffer.capacity();
    }

}
