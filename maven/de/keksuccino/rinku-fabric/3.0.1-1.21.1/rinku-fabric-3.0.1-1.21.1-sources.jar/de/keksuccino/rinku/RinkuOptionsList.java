package de.keksuccino.rinku;

import java.util.List;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_4265;
import net.minecraft.class_6379;
import net.minecraft.class_8030;

/** Native 1.21.1 scrolling container used by each options tab. */
final class RinkuOptionsList extends class_4265<RinkuOptionsList.Entry> {

    private static final int ROW_MAX_WIDTH = 360;
    private static final int ROW_SIDE_MARGIN = 20;
    private static final int EDITABLE_LABEL_WIDTH = 155;
    private static final int EDITABLE_ROW_GAP = 5;

    RinkuOptionsList(class_310 minecraft, int width) {
        super(minecraft, width, 20, 0, 26);
        this.field_22744 = false;
    }

    void addFullWidth(class_339 widget) {
        this.method_25321(Entry.fullWidth(widget));
        this.reflowRows();
    }

    void addPair(class_339 first, class_339 second) {
        this.method_25321(Entry.pair(first, second));
        this.reflowRows();
    }

    void updateBounds(class_8030 rectangle) {
        int top = rectangle.method_49618() + 4;
        this.method_57714(rectangle.comp_1196(), Math.max(20, rectangle.comp_1197() - 4), top);
        this.reflowRows();
    }

    private void reflowRows() {
        int rowWidth = this.method_25322();
        for (Entry entry : this.method_25396()) entry.setAvailableWidth(rowWidth);
    }

    @Override
    public int method_25322() {
        return Math.min(ROW_MAX_WIDTH, Math.max(40, this.method_25368() - ROW_SIDE_MARGIN * 2));
    }

    static final class Entry extends class_4265.class_4266<Entry> {

        private final List<class_339> children;
        private final boolean paired;
        private int availableWidth;

        private Entry(List<class_339> children, boolean paired) {
            this.children = List.copyOf(children);
            this.paired = paired;
        }

        static Entry fullWidth(class_339 widget) {
            return new Entry(List.of(widget), false);
        }

        static Entry pair(class_339 first, class_339 second) {
            return new Entry(List.of(first, second), true);
        }

        void setAvailableWidth(int availableWidth) {
            this.availableWidth = availableWidth;
            if (!this.paired) {
                this.children.getFirst().method_25358(availableWidth);
                return;
            }

            int labelWidth = Math.min(EDITABLE_LABEL_WIDTH, Math.max(80, availableWidth / 2));
            this.children.get(0).method_25358(labelWidth);
            this.children.get(1).method_25358(Math.max(40, availableWidth - labelWidth - EDITABLE_ROW_GAP));
        }

        @Override
        public void method_25343(class_332 graphics, int index, int top, int left, int width, int height, int mouseX, int mouseY, boolean hovering, float partialTick) {
            if (this.availableWidth != width) this.setAvailableWidth(width);
            int x = left;
            for (class_339 widget : this.children) {
                widget.method_48229(x, top);
                widget.method_25394(graphics, mouseX, mouseY, partialTick);
                x += widget.method_25368() + (this.paired ? EDITABLE_ROW_GAP : 0);
            }
        }

        @Override
        public List<? extends class_364> method_25396() {
            return this.children;
        }

        @Override
        public List<? extends class_6379> method_37025() {
            return this.children;
        }

    }

}
