package de.keksuccino.rinku.mixins;

import de.keksuccino.rinku.Rinku;
import net.minecraft.class_757;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_757.class)
public class MixinGameRenderer {

    @Inject(method = "render", at = @At("HEAD"))
    private void before_render_Rinku(class_9779 deltaTracker, boolean renderLevel, CallbackInfo info) {
        if (Rinku.isInitialized()) {
            Rinku.getApp().getHandle().N_DoMessageLoopWork();
        }
    }

}
