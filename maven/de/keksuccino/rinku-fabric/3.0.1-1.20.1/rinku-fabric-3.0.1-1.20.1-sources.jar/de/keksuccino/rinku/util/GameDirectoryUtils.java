package de.keksuccino.rinku.util;

import de.keksuccino.rinku.platform.Services;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.NotNull;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Objects;
import net.minecraft.class_310;

public class GameDirectoryUtils {

    private static final Logger LOGGER = LogManager.getLogger();

    public static File getGameDirectory() {
        try {
            if (Services.PLATFORM.isOnClient()) {
                class_310 minecraft = class_310.method_1551();
                if ((minecraft != null) && (minecraft.field_1697 != null)) {
                    return minecraft.field_1697;
                }
            } else {
                Path path = Paths.get("server.properties");
                return path.toAbsolutePath().getParent().toFile();
            }
        } catch (Exception ex) {
            LOGGER.error("[Rinku] Failed to get game directory!", ex);
        }
        Path workingDirectory = Paths.get("").toAbsolutePath().normalize();
        if (Files.isDirectory(workingDirectory)) {
            return workingDirectory.toFile();
        }
        return new File(".");
    }

    public static boolean isExistingGameDirectoryPath(@NotNull String path) {
        Objects.requireNonNull(path);
        path = path.replace("\\", "/");
        String gameDir = getGameDirectory().getAbsolutePath().replace("\\", "/");
        if (!path.startsWith(gameDir)) {
            path = gameDir + "/" + path;
        }
        return new File(path).exists();
    }

    public static String getAbsoluteGameDirectoryPath(@NotNull String path) {
        try {
            path = path.replace("\\", "/");
            String gameDir = getGameDirectory().getAbsolutePath().replace("\\", "/");
            if (!path.startsWith(gameDir)) {
                if (path.startsWith("/")) path = path.substring(1);
                return gameDir + "/" + path;
            }
        } catch (Exception ex) {
            LOGGER.error("[Rinku] Failed to get absolute game directory path!", ex);
        }
        return path;
    }

    public static String getPathWithoutGameDirectory(@NotNull String path) {
        Objects.requireNonNull(path);
        File f = new File(getAbsoluteGameDirectoryPath(path));
        String p = f.getAbsolutePath().replace("\\", "/").replace(getGameDirectory().getAbsolutePath().replace("\\", "/"), "");
        if (p.startsWith("/")) p = p.substring(1);
        return p;
    }

}
