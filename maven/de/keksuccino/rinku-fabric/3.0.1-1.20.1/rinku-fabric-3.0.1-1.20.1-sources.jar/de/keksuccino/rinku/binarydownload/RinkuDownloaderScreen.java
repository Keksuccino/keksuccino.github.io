package de.keksuccino.rinku.binarydownload;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class RinkuDownloaderScreen extends class_437 {

    private final class_437 parent;

    public RinkuDownloaderScreen(@Nullable class_437 parent) {
        super(class_2561.method_43471("rinku.downloader.title").method_27692(class_124.field_1065));
        this.parent = parent;
    }

    @Override
    public void method_25394(@NotNull class_332 graphics, int mouseX, int mouseY, float partialTick) {

        this.method_25420(graphics);
        super.method_25394(graphics, mouseX, mouseY, partialTick);

        double cx = field_22789 / 2d;
        double cy = field_22790 / 2d;
        double progressBarHeight = 14;
        double progressBarWidth = field_22789 / 3d;

        class_4587 matrix = graphics.method_51448();

        /* Draw Progress Bar */
        matrix.method_22903();
        matrix.method_46416((float) cx, (float) cy, 0.0F);
        matrix.method_46416((float) (-progressBarWidth / 2d), (float) (-progressBarHeight / 2d), 0.0F);
        graphics.method_25294( // bar border
                0, 0,
                (int) progressBarWidth,
                (int) progressBarHeight,
                -1
        );
        graphics.method_25294( // bar padding
                2, 2,
                (int) progressBarWidth - 2,
                (int) progressBarHeight - 2,
                -16777215
        );
        graphics.method_25294( // bar bar
                4, 4,
                (int) ((progressBarWidth - 4) * RinkuDownloadListener.INSTANCE.getProgress()),
                (int) progressBarHeight - 4,
                -1
        );
        matrix.method_22909();

        // putting this here incase I want to re-add a third line later on
        // allows me to generalize the code to not care about line count
        class_2561[] text = new class_2561[] {
                RinkuDownloadListener.INSTANCE.getTask(),
                class_2561.method_43469("rinku.downloader.progress", Math.round(RinkuDownloadListener.INSTANCE.getProgress() * 100)),
        };

        /* Draw Text */

        // calculate offset for the top line
        int oSet = ((field_22793.field_2000 / 2) + ((field_22793.field_2000 + 2) * (text.length + 2))) + 4;
        matrix.method_22903();
        matrix.method_46416((float) cx, (float) (cy - oSet), 0.0F);
        // draw menu name
        graphics.method_27535(this.field_22793, this.field_22785, (int) -(field_22793.method_27525(this.field_22785) / 2d), 0, -1);
        // draw other text
        int index = 0;
        for (class_2561 s : text) {
            if (index == 1) {
                matrix.method_46416(0.0F, field_22793.field_2000 + 2.0F, 0.0F);
            }
            matrix.method_46416(0.0F, field_22793.field_2000 + 2.0F, 0.0F);
            graphics.method_27535(this.field_22793, s, (int) -(field_22793.method_27525(s) / 2d), 0, -1);
            index++;
        }
        matrix.method_22909();

    }

    @Override
    public void method_25393() {
        if (RinkuDownloadListener.INSTANCE.isDone() || RinkuDownloadListener.INSTANCE.isFailed()) {
            class_310.method_1551().method_1507(this.parent);
        }
    }

    @Override
    public boolean method_25422() {
        return false;
    }

    @Override
    public boolean method_25421() {
        return true;
    }

}
