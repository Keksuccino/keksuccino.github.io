package de.keksuccino.rinku.binarydownload;

import java.util.Objects;
import net.minecraft.class_2561;

public class RinkuDownloadListener {

    public static final RinkuDownloadListener INSTANCE = new RinkuDownloadListener();

    // The installer runs on Rinku-Downloader while the render thread polls this state. Volatile
    // publication keeps progress and the terminal state visible without tying either thread to a
    // UI lock during network and extraction work.
    private volatile class_2561 task = class_2561.method_43473();
    private volatile float percent;
    private volatile boolean done;
    private volatile boolean failed;

    private RinkuDownloadListener() {}

    public void setTask(class_2561 task) {
        this.task = Objects.requireNonNull(task, "Downloader task must not be null");
        this.percent = 0;
    }

    public class_2561 getTask() {
        return task;
    }

    public void setProgress(float percent) {
        this.percent = percent;
    }

    public float getProgress() {
        return percent;
    }

    public void setDone(boolean done) {
        this.done = done;
    }

    public boolean isDone() {
        return done;
    }

    public void setFailed(boolean failed) {
        this.failed = failed;
    }

    public boolean isFailed() {
        return failed;
    }

}
