package de.keksuccino.rinku;

import de.keksuccino.rinku.binarydownload.RinkuDownloader;
import org.cef.CefSettings;

import javax.annotation.Nullable;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_342;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_4265;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_6379;
import net.minecraft.class_7842;
import net.minecraft.class_7919;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

/** Rinku's loader-independent configuration screen, adapted to 1.20.1's immediate-mode GUI API. */
public class OptionsScreen extends class_437 {

    private static final int BUTTON_HEIGHT = 20;
    private static final int BUTTON_ROW_MAX_WIDTH = 360;
    private static final int EDITABLE_LABEL_WIDTH = 155;
    private static final int EDITABLE_ROW_GAP = 5;
    private static final int OPTION_ROW_HEIGHT = 26;
    private static final int HEADER_HEIGHT = 45;
    private static final int FOOTER_HEIGHT = 36;
    private static final int CYCLE_VALUE_COLOR = 0xFFAA00;
    private static final int INVALID_TEXT_COLOR = 0xFFFF5555;
    private static final int BROWSER_TAB_INDEX = 0;
    private static final int DOWNLOADS_TAB_INDEX = 1;
    private static final int ADVANCED_TAB_INDEX = 2;

    @Nullable
    private final class_437 parent;
    private final RinkuSettings settings;
    private final List<TextOption<?>> textOptions;
    private final Map<String, String> pendingTextValues = new HashMap<>();
    private final List<TextOptionControl<?>> visibleTextControls = new ArrayList<>();
    private final List<class_4185> tabButtons = new ArrayList<>();
    private final double[] tabScrollAmounts = new double[3];
    private int currentTabIndex = BROWSER_TAB_INDEX;
    @Nullable
    private OptionsList optionsList;
    @Nullable
    private class_4185 transparentPoolSizeButton;
    @Nullable
    private class_4185 opaquePoolSizeButton;

    public OptionsScreen(@Nullable class_437 parent) {
        super(class_2561.method_43471("rinku.options"));
        this.parent = parent;
        this.settings = Rinku.getSettings();
        this.initializePendingTextValues();
        this.textOptions = this.createTextOptions();
    }

    @Override
    protected void method_25426() {
        this.visibleTextControls.clear();
        this.tabButtons.clear();
        this.transparentPoolSizeButton = null;
        this.opaquePoolSizeButton = null;
        this.addTabButtons();
        this.optionsList = this.method_37063(new OptionsList(this.field_22787, this.field_22789, this.field_22790, HEADER_HEIGHT, Math.max(HEADER_HEIGHT + OPTION_ROW_HEIGHT, this.field_22790 - FOOTER_HEIGHT), OPTION_ROW_HEIGHT));
        this.buildCurrentTab();
        this.optionsList.method_25307(this.tabScrollAmounts[this.currentTabIndex]);
        this.method_37063(class_4185.method_46430(class_5244.field_24334, ignored -> this.method_25419()).method_46434((this.field_22789 - 150) / 2, this.field_22790 - 28, 150, BUTTON_HEIGHT).method_46431());
        this.updateTabButtons();
        this.updatePreloadControls();
        this.validateVisibleTextOptions();
    }

    private void addTabButtons() {
        int availableWidth = Math.max(180, this.field_22789 - 40);
        int tabWidth = Math.min(120, availableWidth / 3);
        int startX = (this.field_22789 - tabWidth * 3) / 2;
        this.tabButtons.add(this.method_37063(class_4185.method_46430(class_2561.method_43471("rinku.options.tab.browser"), ignored -> this.switchTab(BROWSER_TAB_INDEX)).method_46434(startX, 8, tabWidth, BUTTON_HEIGHT).method_46431()));
        this.tabButtons.add(this.method_37063(class_4185.method_46430(class_2561.method_43471("rinku.options.tab.downloads"), ignored -> this.switchTab(DOWNLOADS_TAB_INDEX)).method_46434(startX + tabWidth, 8, tabWidth, BUTTON_HEIGHT).method_46431()));
        this.tabButtons.add(this.method_37063(class_4185.method_46430(class_2561.method_43471("rinku.options.tab.advanced"), ignored -> this.switchTab(ADVANCED_TAB_INDEX)).method_46434(startX + tabWidth * 2, 8, tabWidth, BUTTON_HEIGHT).method_46431()));
    }

    private void switchTab(int tabIndex) {
        if (tabIndex == this.currentTabIndex) return;
        this.rememberScrollAmount();
        this.currentTabIndex = tabIndex;
        this.method_41843();
    }

    private void rememberScrollAmount() {
        if (this.optionsList != null) this.tabScrollAmounts[this.currentTabIndex] = this.optionsList.method_25341();
    }

    private void updateTabButtons() {
        for (int index = 0; index < this.tabButtons.size(); index++) this.tabButtons.get(index).field_22763 = index != this.currentTabIndex;
    }

    private void initializePendingTextValues() {
        this.pendingTextValues.put("user-agent", this.settings.getUserAgent() == null ? "" : this.settings.getUserAgent());
        this.pendingTextValues.put("download-mirror", this.settings.getDownloadMirror() == null ? "" : this.settings.getDownloadMirror());
        this.pendingTextValues.put("download-connect-timeout-ms", Integer.toString(this.settings.getDownloadConnectTimeoutMs()));
        this.pendingTextValues.put("download-read-timeout-ms", Integer.toString(this.settings.getDownloadReadTimeoutMs()));
        this.pendingTextValues.put("download-max-archive-bytes", Long.toString(this.settings.getDownloadMaxArchiveBytes()));
        this.pendingTextValues.put("download-max-checksum-bytes", Long.toString(this.settings.getDownloadMaxChecksumBytes()));
        this.pendingTextValues.put("download-max-extracted-bytes", Long.toString(this.settings.getDownloadMaxExtractedBytes()));
    }

    private List<TextOption<?>> createTextOptions() {
        List<TextOption<?>> options = new ArrayList<>();
        options.add(new TextOption<>(BROWSER_TAB_INDEX, "user-agent", "rinku.options.user_agent", "rinku.options.user_agent.desc", 512, RinkuOptionsInput::parseUserAgent, this.settings::getUserAgent, this.settings::setUserAgent, class_2561.method_43471("rinku.options.validation.user_agent")));
        options.add(new TextOption<>(DOWNLOADS_TAB_INDEX, "download-mirror", "rinku.options.download_mirror", "rinku.options.download_mirror.desc", 2048, this::parseDownloadMirror, this.settings::getDownloadMirror, this.settings::setDownloadMirror, class_2561.method_43471("rinku.options.validation.download_mirror")));
        options.add(new TextOption<>(DOWNLOADS_TAB_INDEX, "download-connect-timeout-ms", "rinku.options.connect_timeout", "rinku.options.connect_timeout.desc", 6, value -> RinkuOptionsInput.parseInt(value, RinkuSettings.MIN_DOWNLOAD_TIMEOUT_MS, RinkuSettings.MAX_DOWNLOAD_TIMEOUT_MS), this.settings::getDownloadConnectTimeoutMs, this.settings::setDownloadConnectTimeoutMs, class_2561.method_43469("rinku.options.validation.integer_range", RinkuSettings.MIN_DOWNLOAD_TIMEOUT_MS, RinkuSettings.MAX_DOWNLOAD_TIMEOUT_MS)));
        options.add(new TextOption<>(DOWNLOADS_TAB_INDEX, "download-read-timeout-ms", "rinku.options.read_timeout", "rinku.options.read_timeout.desc", 6, value -> RinkuOptionsInput.parseInt(value, RinkuSettings.MIN_DOWNLOAD_TIMEOUT_MS, RinkuSettings.MAX_DOWNLOAD_TIMEOUT_MS), this.settings::getDownloadReadTimeoutMs, this.settings::setDownloadReadTimeoutMs, class_2561.method_43469("rinku.options.validation.integer_range", RinkuSettings.MIN_DOWNLOAD_TIMEOUT_MS, RinkuSettings.MAX_DOWNLOAD_TIMEOUT_MS)));
        options.add(new TextOption<>(DOWNLOADS_TAB_INDEX, "download-max-archive-bytes", "rinku.options.max_archive_bytes", "rinku.options.max_archive_bytes.desc", 10, value -> RinkuOptionsInput.parseLong(value, RinkuSettings.MIN_DOWNLOAD_ARCHIVE_BYTES, RinkuSettings.MAX_DOWNLOAD_ARCHIVE_BYTES), this.settings::getDownloadMaxArchiveBytes, this.settings::setDownloadMaxArchiveBytes, class_2561.method_43469("rinku.options.validation.integer_range", RinkuSettings.MIN_DOWNLOAD_ARCHIVE_BYTES, RinkuSettings.MAX_DOWNLOAD_ARCHIVE_BYTES)));
        options.add(new TextOption<>(DOWNLOADS_TAB_INDEX, "download-max-checksum-bytes", "rinku.options.max_checksum_bytes", "rinku.options.max_checksum_bytes.desc", 7, value -> RinkuOptionsInput.parseLong(value, RinkuSettings.MIN_DOWNLOAD_CHECKSUM_BYTES, RinkuSettings.MAX_DOWNLOAD_CHECKSUM_BYTES), this.settings::getDownloadMaxChecksumBytes, this.settings::setDownloadMaxChecksumBytes, class_2561.method_43469("rinku.options.validation.integer_range", RinkuSettings.MIN_DOWNLOAD_CHECKSUM_BYTES, RinkuSettings.MAX_DOWNLOAD_CHECKSUM_BYTES)));
        options.add(new TextOption<>(DOWNLOADS_TAB_INDEX, "download-max-extracted-bytes", "rinku.options.max_extracted_bytes", "rinku.options.max_extracted_bytes.desc", 11, value -> RinkuOptionsInput.parseLong(value, RinkuSettings.MIN_DOWNLOAD_EXTRACTED_BYTES, RinkuSettings.MAX_DOWNLOAD_EXTRACTED_BYTES), this.settings::getDownloadMaxExtractedBytes, this.settings::setDownloadMaxExtractedBytes, class_2561.method_43469("rinku.options.validation.integer_range", RinkuSettings.MIN_DOWNLOAD_EXTRACTED_BYTES, RinkuSettings.MAX_DOWNLOAD_EXTRACTED_BYTES)));
        return List.copyOf(options);
    }

    private void buildCurrentTab() {
        if (this.optionsList == null) return;
        if (this.currentTabIndex == BROWSER_TAB_INDEX) {
            this.addTextOption(this.findTextOption("user-agent"));
            this.addFullWidthOption(this.buildBooleanButton("rinku.options.use_cache", "rinku.options.use_cache.desc", this.settings::isUsingCache, this.settings::setUseCache));
            this.addFullWidthOption(this.buildBooleanButton("rinku.options.enable_widevine", "rinku.options.enable_widevine.desc", this.settings::isEnableWidevineCdm, this.settings::setEnableWidevineCdm));
            this.addFullWidthOption(this.buildPreloadEnabledButton());
            this.transparentPoolSizeButton = this.buildPoolSizeButton("rinku.options.preload_transparent_pool_size", "rinku.options.preload_transparent_pool_size.desc", this.settings::getBrowserPreloadTransparentPoolSize, this.settings::setBrowserPreloadTransparentPoolSize);
            this.opaquePoolSizeButton = this.buildPoolSizeButton("rinku.options.preload_opaque_pool_size", "rinku.options.preload_opaque_pool_size.desc", this.settings::getBrowserPreloadOpaquePoolSize, this.settings::setBrowserPreloadOpaquePoolSize);
            this.addFullWidthOption(this.transparentPoolSizeButton);
            this.addFullWidthOption(this.opaquePoolSizeButton);
            return;
        }
        if (this.currentTabIndex == DOWNLOADS_TAB_INDEX) {
            this.addFullWidthOption(this.buildBooleanButton("rinku.options.skip_download", "rinku.options.skip_download.desc", this.settings::isSkipDownload, this.settings::setSkipDownload));
            this.addFullWidthOption(this.buildMirrorPolicyButton());
            this.addTextOption(this.findTextOption("download-mirror"));
            this.addFullWidthOption(this.buildBooleanButton("rinku.options.enforce_checksums", "rinku.options.enforce_checksums.desc", this.settings::isEnforceDownloadChecksums, this.settings::setEnforceDownloadChecksums));
            this.addTextOption(this.findTextOption("download-connect-timeout-ms"));
            this.addTextOption(this.findTextOption("download-read-timeout-ms"));
            this.addTextOption(this.findTextOption("download-max-archive-bytes"));
            this.addTextOption(this.findTextOption("download-max-checksum-bytes"));
            this.addTextOption(this.findTextOption("download-max-extracted-bytes"));
            return;
        }
        this.addFullWidthOption(this.buildBooleanButton("rinku.options.disable_web_security", "rinku.options.disable_web_security.desc", this.settings::isDisableWebSecurity, this.settings::setDisableWebSecurity));
        this.addFullWidthOption(this.buildLogSeverityButton("rinku.options.native_log_severity", "rinku.options.native_log_severity.desc", this.settings::getNativeCefLogSeverity, this.settings::setNativeCefLogSeverity));
        this.addFullWidthOption(this.buildLogSeverityButton("rinku.options.console_log_severity", "rinku.options.console_log_severity.desc", this.settings::getConsoleLogForwardingMinSeverity, this.settings::setConsoleLogForwardingMinSeverity));
    }

    private TextOption<?> findTextOption(String id) {
        for (TextOption<?> option : this.textOptions) {
            if (option.id().equals(id)) return option;
        }
        throw new IllegalStateException("Missing Rinku text option " + id);
    }

    private class_4185 buildPreloadEnabledButton() {
        return class_4185.method_46430(this.booleanOptionMessage("rinku.options.preload_enabled", this.settings.isBrowserPreloadEnabled()), pressedButton -> {
            this.settings.setBrowserPreloadEnabled(!this.settings.isBrowserPreloadEnabled());
            pressedButton.method_25355(this.booleanOptionMessage("rinku.options.preload_enabled", this.settings.isBrowserPreloadEnabled()));
            this.updatePreloadControls();
        }).method_46432(this.getButtonWidth()).method_46436(class_7919.method_47407(class_2561.method_43471("rinku.options.preload_enabled.desc"))).method_46431();
    }

    private class_4185 buildMirrorPolicyButton() {
        return class_4185.method_46430(this.mirrorPolicyMessage(), pressedButton -> {
            this.settings.setDownloadMirrorPolicy(nextValue(this.settings.getDownloadMirrorPolicy(), RinkuDownloader.MirrorPolicy.values()));
            pressedButton.method_25355(this.mirrorPolicyMessage());
            this.validateVisibleTextOptions();
        }).method_46432(this.getButtonWidth()).method_46436(class_7919.method_47407(class_2561.method_43471("rinku.options.download_mirror_policy.desc"))).method_46431();
    }

    private class_4185 buildLogSeverityButton(String labelKey, String descriptionKey, Supplier<CefSettings.LogSeverity> getter, Consumer<CefSettings.LogSeverity> setter) {
        return class_4185.method_46430(this.logSeverityMessage(labelKey, getter.get()), pressedButton -> {
            CefSettings.LogSeverity next = nextValue(getter.get(), CefSettings.LogSeverity.values());
            setter.accept(next);
            pressedButton.method_25355(this.logSeverityMessage(labelKey, next));
        }).method_46432(this.getButtonWidth()).method_46436(class_7919.method_47407(class_2561.method_43471(descriptionKey))).method_46431();
    }

    private class_4185 buildPoolSizeButton(String labelKey, String descriptionKey, Supplier<Integer> getter, Consumer<Integer> setter) {
        return class_4185.method_46430(this.integerOptionMessage(labelKey, getter.get()), pressedButton -> {
            int next = getter.get() >= RinkuSettings.MAX_BROWSER_PRELOAD_POOL_SIZE ? RinkuSettings.MIN_BROWSER_PRELOAD_POOL_SIZE : getter.get() + 1;
            setter.accept(next);
            pressedButton.method_25355(this.integerOptionMessage(labelKey, next));
        }).method_46432(this.getButtonWidth()).method_46436(class_7919.method_47407(class_2561.method_43471(descriptionKey))).method_46431();
    }

    private class_4185 buildBooleanButton(String labelKey, String descriptionKey, Supplier<Boolean> getter, Consumer<Boolean> setter) {
        return class_4185.method_46430(this.booleanOptionMessage(labelKey, getter.get()), pressedButton -> {
            boolean next = !getter.get();
            setter.accept(next);
            pressedButton.method_25355(this.booleanOptionMessage(labelKey, next));
        }).method_46432(this.getButtonWidth()).method_46436(class_7919.method_47407(class_2561.method_43471(descriptionKey))).method_46431();
    }

    private void addFullWidthOption(class_4185 button) {
        if (this.optionsList != null) this.optionsList.addOption(new OptionEntry(List.of(button), false));
    }

    private <T> void addTextOption(TextOption<T> option) {
        class_2561 label = class_2561.method_43471(option.labelKey());
        class_2561 description = class_2561.method_43471(option.descriptionKey());
        String initialValue = this.pendingTextValues.getOrDefault(option.id(), "");
        class_7842 labelWidget = new class_7842(EDITABLE_LABEL_WIDTH, BUTTON_HEIGHT, label, this.field_22793).method_48596();
        class_342 editBox = new class_342(this.field_22793, 0, 0, Math.max(40, this.getButtonWidth() - EDITABLE_LABEL_WIDTH - EDITABLE_ROW_GAP), BUTTON_HEIGHT, label);
        labelWidget.method_47400(class_7919.method_47407(description));
        editBox.method_1880(Math.max(option.maxLength(), initialValue.length()));
        editBox.method_1852(initialValue);
        editBox.method_47400(class_7919.method_47407(description));
        OptionEntry entry = new OptionEntry(List.of(labelWidget, editBox), true);
        TextOptionControl<T> control = new TextOptionControl<>(option, editBox, description, entry);
        editBox.method_1863(value -> {
            this.pendingTextValues.put(option.id(), value);
            control.validate();
        });
        this.visibleTextControls.add(control);
        if (this.optionsList != null) this.optionsList.addOption(entry);
    }

    private String parseDownloadMirror(String value) {
        return RinkuOptionsInput.parseMirror(value, this.settings.getDownloadMirrorPolicy() != RinkuDownloader.MirrorPolicy.CONFIGURED_ONLY);
    }

    private void updatePreloadControls() {
        boolean active = this.settings.isBrowserPreloadEnabled();
        if (this.transparentPoolSizeButton != null) this.transparentPoolSizeButton.field_22763 = active;
        if (this.opaquePoolSizeButton != null) this.opaquePoolSizeButton.field_22763 = active;
    }

    private void validateVisibleTextOptions() {
        for (TextOptionControl<?> control : this.visibleTextControls) control.validate();
    }

    private boolean applyTextOptions() {
        TextOption<?> firstInvalid = null;
        for (TextOption<?> option : this.textOptions) {
            if (!this.isTextOptionValid(option) && firstInvalid == null) firstInvalid = option;
        }
        if (firstInvalid != null) {
            this.rememberScrollAmount();
            this.currentTabIndex = firstInvalid.tabIndex();
            this.method_41843();
            for (TextOptionControl<?> control : this.visibleTextControls) {
                if (control.option().id().equals(firstInvalid.id())) {
                    control.validate();
                    if (this.optionsList != null) this.optionsList.showEntry(control.entry());
                    break;
                }
            }
            return false;
        }
        for (TextOption<?> option : this.textOptions) this.applyTextOption(option);
        return true;
    }

    private <T> boolean isTextOptionValid(TextOption<T> option) {
        try {
            option.parser().apply(this.pendingTextValues.getOrDefault(option.id(), ""));
            return true;
        } catch (IllegalArgumentException exception) {
            return false;
        }
    }

    private <T> void applyTextOption(TextOption<T> option) {
        T parsedValue = option.parser().apply(this.pendingTextValues.getOrDefault(option.id(), ""));
        if (!Objects.equals(parsedValue, option.currentValue().get())) option.applier().accept(parsedValue);
    }

    private class_2561 booleanOptionMessage(String labelKey, boolean enabled) {
        class_2561 value = class_2561.method_43471(enabled ? "rinku.options.toggle.enabled" : "rinku.options.toggle.disabled").method_27696(class_2583.field_24360.method_10977(enabled ? class_124.field_1060 : class_124.field_1061));
        return class_2561.method_43469(labelKey, value);
    }

    private class_2561 integerOptionMessage(String labelKey, int value) {
        return class_2561.method_43469(labelKey, this.cycleValue(class_2561.method_43470(Integer.toString(value))));
    }

    private class_2561 mirrorPolicyMessage() {
        String valueKey = "rinku.options.download_mirror_policy." + this.settings.getDownloadMirrorPolicy().name().toLowerCase(java.util.Locale.ROOT);
        return class_2561.method_43469("rinku.options.download_mirror_policy", this.cycleValue(class_2561.method_43471(valueKey)));
    }

    private class_2561 logSeverityMessage(String labelKey, CefSettings.LogSeverity severity) {
        String severityName = severity.name().substring("LOGSEVERITY_".length()).toLowerCase(java.util.Locale.ROOT);
        return class_2561.method_43469(labelKey, this.cycleValue(class_2561.method_43471("rinku.options.log_severity." + severityName)));
    }

    private class_2561 cycleValue(class_2561 value) {
        return value.method_27661().method_27696(class_2583.field_24360.method_36139(CYCLE_VALUE_COLOR));
    }

    private int getButtonWidth() {
        return Math.max(80, Math.min(BUTTON_ROW_MAX_WIDTH, this.field_22789 - 40));
    }

    private static <T> T nextValue(T current, T[] values) {
        for (int index = 0; index < values.length; index++) {
            if (values[index] == current) return values[(index + 1) % values.length];
        }
        return values[0];
    }

    @Override
    public void method_25393() {
        for (TextOptionControl<?> control : this.visibleTextControls) control.editBox().method_1865();
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        this.method_25420(graphics);
        graphics.method_25294(0, HEADER_HEIGHT - 2, this.field_22789, HEADER_HEIGHT, 0xFF000000);
        graphics.method_25294(0, this.field_22790 - FOOTER_HEIGHT, this.field_22789, this.field_22790 - FOOTER_HEIGHT + 2, 0xFF000000);
        super.method_25394(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public void method_25419() {
        if (!this.applyTextOptions()) return;
        class_310.method_1551().method_1507(this.parent);
    }

    private record TextOption<T>(int tabIndex, String id, String labelKey, String descriptionKey, int maxLength, Function<String, T> parser, Supplier<T> currentValue, Consumer<T> applier, class_2561 invalidMessage) {
    }

    private final class TextOptionControl<T> {

        private final TextOption<T> option;
        private final class_342 editBox;
        private final class_2561 description;
        private final OptionEntry entry;

        private TextOptionControl(TextOption<T> option, class_342 editBox, class_2561 description, OptionEntry entry) {
            this.option = option;
            this.editBox = editBox;
            this.description = description;
            this.entry = entry;
        }

        private boolean validate() {
            try {
                this.option.parser().apply(this.editBox.method_1882());
                this.editBox.method_1868(class_342.field_32196);
                this.editBox.method_47400(class_7919.method_47407(this.description));
                return true;
            } catch (IllegalArgumentException exception) {
                this.editBox.method_1868(INVALID_TEXT_COLOR);
                this.editBox.method_47400(class_7919.method_47407(this.option.invalidMessage()));
                return false;
            }
        }

        private TextOption<T> option() {
            return this.option;
        }

        private class_342 editBox() {
            return this.editBox;
        }

        private OptionEntry entry() {
            return this.entry;
        }

    }

    private static final class OptionEntry extends class_4265.class_4266<OptionEntry> {

        private final List<class_339> widgets;
        private final boolean editablePair;

        private OptionEntry(List<class_339> widgets, boolean editablePair) {
            this.widgets = widgets;
            this.editablePair = editablePair;
        }

        @Override
        public void method_25343(class_332 graphics, int index, int top, int left, int width, int height, int mouseX, int mouseY, boolean hovering, float partialTick) {
            if (!this.editablePair) {
                class_339 widget = this.widgets.get(0);
                widget.method_46421(left);
                widget.method_46419(top);
                widget.method_25358(width);
                widget.method_25394(graphics, mouseX, mouseY, partialTick);
                return;
            }
            int labelWidth = Math.min(EDITABLE_LABEL_WIDTH, Math.max(80, width / 2));
            class_339 label = this.widgets.get(0);
            class_339 editBox = this.widgets.get(1);
            label.method_46421(left);
            label.method_46419(top);
            label.method_25358(labelWidth);
            editBox.method_46421(left + labelWidth + EDITABLE_ROW_GAP);
            editBox.method_46419(top);
            editBox.method_25358(Math.max(40, width - labelWidth - EDITABLE_ROW_GAP));
            label.method_25394(graphics, mouseX, mouseY, partialTick);
            editBox.method_25394(graphics, mouseX, mouseY, partialTick);
        }

        @Override
        public List<? extends class_364> method_25396() {
            return this.widgets;
        }

        @Override
        public List<? extends class_6379> method_37025() {
            return this.widgets;
        }

    }

    private static final class OptionsList extends class_4265<OptionEntry> {

        private OptionsList(class_310 minecraft, int width, int height, int top, int bottom, int rowHeight) {
            super(minecraft, width, height, top, bottom, rowHeight);
            this.field_22744 = false;
            this.method_31322(false);
            this.method_31323(false);
        }

        private void addOption(OptionEntry entry) {
            this.method_25321(entry);
        }

        private void showEntry(OptionEntry entry) {
            this.method_25328(entry);
        }

        @Override
        public int method_25322() {
            return Math.max(80, Math.min(BUTTON_ROW_MAX_WIDTH, this.field_22742 - 40));
        }

        @Override
        protected int method_25329() {
            return this.field_22742 / 2 + this.method_25322() / 2 + 4;
        }

    }

}
